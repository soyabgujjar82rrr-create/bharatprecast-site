package com.example.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.R
import com.example.permissions.PermissionHelper

object NotificationHelper {

    const val CHANNEL_CALL_HANDLED = "channel_ai_call_handled"
    const val CHANNEL_CALL_SUMMARY = "channel_call_summary_ready"
    const val CHANNEL_AI_EVENTS = "channel_important_ai_events"
    const val CHANNEL_PERMISSIONS = "channel_permission_reminders"

    fun initNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                ?: return

            val callHandledChannel = NotificationChannel(
                CHANNEL_CALL_HANDLED,
                "AI Call Handled",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications when EquiliAI answers or screens incoming calls"
            }

            val summaryChannel = NotificationChannel(
                CHANNEL_CALL_SUMMARY,
                "Call Summaries Ready",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications when an AI-generated call summary is ready to review"
            }

            val aiEventsChannel = NotificationChannel(
                CHANNEL_AI_EVENTS,
                "Important AI Events",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Status alerts and key intelligence updates from EquiliAI Max"
            }

            val permissionsChannel = NotificationChannel(
                CHANNEL_PERMISSIONS,
                "Permission Reminders",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Reminders when essential voice or phone permissions are missing"
            }

            notificationManager.createNotificationChannels(
                listOf(callHandledChannel, summaryChannel, aiEventsChannel, permissionsChannel)
            )
        }
    }

    fun postNotification(
        context: Context,
        channelId: String,
        notificationId: Int,
        title: String,
        content: String
    ) {
        if (!PermissionHelper.isPermissionGranted(context, android.Manifest.permission.POST_NOTIFICATIONS) &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
        ) {
            return
        }

        try {
            val builder = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.equiliai_logo)
                .setContentTitle(title)
                .setContentText(content)
                .setStyle(NotificationCompat.BigTextStyle().bigText(content))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)

            NotificationManagerCompat.from(context).notify(notificationId, builder.build())
        } catch (_: SecurityException) {
            // Permission denied or revoked
        }
    }
}
