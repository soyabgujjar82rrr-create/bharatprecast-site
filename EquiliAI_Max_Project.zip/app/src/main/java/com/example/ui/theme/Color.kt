package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand palette - EquiliAI Max Electric Intelligence
val EquiliPrimary = Color(0xFF6366F1) // Electric Indigo
val EquiliOnPrimary = Color(0xFFFFFFFF)
val EquiliPrimaryContainer = Color(0xFF282B48)
val EquiliOnPrimaryContainer = Color(0xFFE0E7FF)

val EquiliSecondary = Color(0xFF06B6D4) // Cyan Spark
val EquiliOnSecondary = Color(0xFF00363D)
val EquiliSecondaryContainer = Color(0xFF164E63)
val EquiliOnSecondaryContainer = Color(0xFFA5F3FC)

val EquiliTertiary = Color(0xFF8B5CF6) // Violet Accent
val EquiliOnTertiary = Color(0xFFFFFFFF)
val EquiliTertiaryContainer = Color(0xFF381E72)
val EquiliOnTertiaryContainer = Color(0xFFEDE9FE)

// Surfaces - Dark Theme
val EquiliDarkBackground = Color(0xFF080C14)
val EquiliDarkSurface = Color(0xFF0E1524)
val EquiliDarkSurfaceVariant = Color(0xFF172036)
val EquiliDarkOutline = Color(0xFF2E3E5B)
val EquiliDarkOnSurface = Color(0xFFF1F5F9)
val EquiliDarkOnSurfaceVariant = Color(0xFF94A3B8)

// Surfaces - Light Theme
val EquiliLightBackground = Color(0xFFF8FAFC)
val EquiliLightSurface = Color(0xFFFFFFFF)
val EquiliLightSurfaceVariant = Color(0xFFEEF2F6)
val EquiliLightOutline = Color(0xFFCBD5E1)
val EquiliLightOnSurface = Color(0xFF0F172A)
val EquiliLightOnSurfaceVariant = Color(0xFF475569)

// Semantic
val EquiliSuccess = Color(0xFF10B981)
val EquiliWarning = Color(0xFFF59E0B)
val EquiliError = Color(0xFFEF4444)
val EquiliNeonCyan = Color(0xFF00F2FE)
val EquiliNeonPurple = Color(0xFF9D4EDD)
