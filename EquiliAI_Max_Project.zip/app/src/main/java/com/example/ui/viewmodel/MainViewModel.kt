package com.example.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.ai.AIResponseResult
import com.example.ai.EquiliAIEngine
import com.example.callassistant.CallAssistantManager
import com.example.callassistant.LiveCallSessionState
import com.example.callassistant.TelecomCapabilityInfo
import com.example.data.entity.CallEventEntity
import com.example.data.entity.ChatMessageEntity
import com.example.data.entity.UserPreferencesEntity
import com.example.data.repository.EquiliRepository
import com.example.permissions.PermissionHelper
import com.example.permissions.PermissionStatusItem
import com.example.voice.TextToSpeechManager
import com.example.voice.VoiceManager
import com.example.voice.VoiceState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class MainUiState(
    val preferences: UserPreferencesEntity = UserPreferencesEntity(),
    val chatMessages: List<ChatMessageEntity> = emptyList(),
    val callEvents: List<CallEventEntity> = emptyList(),
    val voiceState: VoiceState = VoiceState.Idle,
    val isSpeaking: Boolean = false,
    val permissionStatuses: List<PermissionStatusItem> = emptyList(),
    val isProcessingAi: Boolean = false,
    val simulatedScreeningDialog: Boolean = false,
    val simulatedCallerNumber: String = "+1 (555) 019-2834",
    val liveCallSession: LiveCallSessionState = LiveCallSessionState(),
    val telecomCapability: TelecomCapabilityInfo? = null,
    val isCloudConfigured: Boolean = false,
    val memoryTurnCount: Int = 0
)

class MainViewModel(
    private val repository: EquiliRepository,
    private val aiEngine: EquiliAIEngine,
    private val callAssistantManager: CallAssistantManager,
    private val voiceManager: VoiceManager,
    private val ttsManager: TextToSpeechManager
) : ViewModel() {

    private val _permissionStatuses = MutableStateFlow<List<PermissionStatusItem>>(emptyList())
    private val _isProcessingAi = MutableStateFlow(false)
    private val _simulatedScreeningDialog = MutableStateFlow(false)
    private val _simulatedCallerNumber = MutableStateFlow("+1 (555) 019-2834")
    private val _telecomCapability = MutableStateFlow<TelecomCapabilityInfo?>(null)
    private val _conversationMemory = MutableStateFlow<List<Pair<String, String>>>(emptyList())

    val uiState: StateFlow<MainUiState> = combine(
        repository.preferencesFlow,
        repository.chatMessagesFlow,
        repository.callEventsFlow,
        voiceManager.voiceState,
        ttsManager.isSpeaking
    ) { prefs, messages, calls, voice, speaking ->
        MainUiState(
            preferences = prefs,
            chatMessages = messages,
            callEvents = calls,
            voiceState = voice,
            isSpeaking = speaking,
            isCloudConfigured = aiEngine.isCloudConfigured()
        )
    }.combine(_permissionStatuses) { state, perms ->
        state.copy(permissionStatuses = perms)
    }.combine(_isProcessingAi) { state, processing ->
        state.copy(isProcessingAi = processing)
    }.combine(_simulatedScreeningDialog) { state, simDialog ->
        state.copy(
            simulatedScreeningDialog = simDialog,
            simulatedCallerNumber = _simulatedCallerNumber.value
        )
    }.combine(callAssistantManager.sessionState) { state, callSession ->
        state.copy(liveCallSession = callSession)
    }.combine(_telecomCapability) { state, capability ->
        state.copy(telecomCapability = capability)
    }.combine(_conversationMemory) { state, memory ->
        state.copy(memoryTurnCount = memory.size)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = MainUiState(isCloudConfigured = aiEngine.isCloudConfigured())
    )

    init {
        // Collect voice recognition results to trigger AI responses for normal assistant
        viewModelScope.launch {
            voiceManager.voiceState.collect { state ->
                val callActive = callAssistantManager.sessionState.value.isActive
                if (!callActive && state is VoiceState.Recognized) {
                    processUserQuery(state.text)
                }
            }
        }
    }

    fun updatePermissionStatuses(context: Context) {
        _permissionStatuses.value = PermissionHelper.getPermissionStatuses(context)
        _telecomCapability.value = callAssistantManager.getTelecomCapability(context)
    }

    fun refreshTelecomCapability(context: Context) {
        _telecomCapability.value = callAssistantManager.getTelecomCapability(context)
    }

    fun onConsentAgreed() {
        viewModelScope.launch {
            repository.setConsentAgreed(true)
        }
    }

    fun completeSetup() {
        viewModelScope.launch {
            repository.markSetupCompleted(true)
        }
    }

    fun restartSetup() {
        viewModelScope.launch {
            repository.markSetupCompleted(false)
            repository.setConsentAgreed(false)
        }
    }

    fun startListening() {
        val currentPrefs = uiState.value.preferences
        val langCode = if (currentPrefs.assistantLanguage == "hi") "hi-IN" else "en-US"
        voiceManager.startListening(langCode)
    }

    fun stopListening() {
        voiceManager.stopListening()
    }

    fun resetVoiceState() {
        voiceManager.resetState()
    }

    fun processUserQuery(query: String) {
        if (query.isBlank()) return
        val currentPrefs = uiState.value.preferences

        viewModelScope.launch {
            repository.addChatMessage(sender = "user", content = query, originalQuery = query)
            _isProcessingAi.value = true

            val memoryContext = if (currentPrefs.aiMemoryEnabled) {
                _conversationMemory.value
            } else {
                emptyList()
            }

            val result = aiEngine.processQuery(
                prompt = query,
                language = currentPrefs.assistantLanguage,
                isCallContext = false,
                historyTurns = memoryContext
            )

            _isProcessingAi.value = false
            voiceManager.resetState()

            when (result) {
                is AIResponseResult.Success -> {
                    repository.addChatMessage(
                        sender = "assistant",
                        content = result.text,
                        originalQuery = query
                    )
                    if (currentPrefs.aiMemoryEnabled) {
                        _conversationMemory.value = (memoryContext + listOf("user" to query, "assistant" to result.text)).takeLast(10)
                    }
                    if (currentPrefs.autoSpeakEnabled) {
                        speakText(result.text)
                    }
                }
                is AIResponseResult.Error -> {
                    repository.addChatMessage(
                        sender = "assistant",
                        content = result.fallbackText,
                        isError = true,
                        originalQuery = query
                    )
                    if (currentPrefs.aiMemoryEnabled) {
                        _conversationMemory.value = (memoryContext + listOf("user" to query, "assistant" to result.fallbackText)).takeLast(10)
                    }
                    if (currentPrefs.autoSpeakEnabled) {
                        speakText(result.fallbackText)
                    }
                }
            }
        }
    }

    fun retryQuery(originalQuery: String) {
        if (originalQuery.isNotBlank()) {
            processUserQuery(originalQuery)
        }
    }

    fun startNewChat() {
        _conversationMemory.value = emptyList()
        viewModelScope.launch {
            repository.clearChatMessages()
        }
    }

    fun clearConversationMemory() {
        _conversationMemory.value = emptyList()
    }

    fun setAiMemoryEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.setAiMemoryEnabled(enabled)
            if (!enabled) {
                _conversationMemory.value = emptyList()
            }
        }
    }

    fun speakText(text: String) {
        val prefs = uiState.value.preferences
        ttsManager.speak(
            text = text,
            languageCode = prefs.assistantLanguage,
            speechRate = prefs.speechRate,
            pitch = prefs.speechPitch
        )
    }

    fun stopSpeaking() {
        ttsManager.stop()
    }

    fun clearChat() {
        _conversationMemory.value = emptyList()
        viewModelScope.launch {
            repository.clearChatMessages()
        }
    }

    fun toggleAssistant(enabled: Boolean) {
        viewModelScope.launch {
            repository.setAssistantEnabled(enabled)
        }
    }

    // Call Assistant Controls & Preferences
    fun toggleCallAssistant(enabled: Boolean) {
        viewModelScope.launch {
            repository.setCallAssistantEnabled(enabled)
        }
    }

    fun setLetAiAnswerCalls(enabled: Boolean) {
        viewModelScope.launch {
            repository.setLetAiAnswerCalls(enabled)
        }
    }

    fun setAskMeBeforeAiAnswers(enabled: Boolean) {
        viewModelScope.launch {
            repository.setAskMeBeforeAiAnswers(enabled)
        }
    }

    fun setTransferCallToMeEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.setTransferCallToMeEnabled(enabled)
        }
    }

    fun setCallGreetingText(greeting: String) {
        viewModelScope.launch {
            repository.setCallGreetingText(greeting)
        }
    }

    fun setAiVoiceId(voiceId: String) {
        viewModelScope.launch {
            repository.setAiVoiceId(voiceId)
        }
    }

    fun setSaveTranscriptsConsent(consent: Boolean) {
        viewModelScope.launch {
            repository.setSaveTranscriptsConsent(consent)
        }
    }

    fun setGenerateAiSummaries(enabled: Boolean) {
        viewModelScope.launch {
            repository.setGenerateAiSummaries(enabled)
        }
    }

    fun setCallScreeningMode(mode: String) {
        viewModelScope.launch {
            repository.setCallScreeningMode(mode)
        }
    }

    fun setLanguage(language: String) {
        viewModelScope.launch {
            repository.setAssistantLanguage(language)
        }
    }

    fun setAutoSpeak(enabled: Boolean) {
        viewModelScope.launch {
            repository.setAutoSpeak(enabled)
        }
    }

    fun setVoiceRateAndPitch(rate: Float, pitch: Float) {
        viewModelScope.launch {
            repository.setVoiceSettings(rate, pitch)
        }
    }

    fun setNotificationSettings(
        callHandled: Boolean,
        summaryReady: Boolean,
        aiEvents: Boolean,
        permissionReminders: Boolean
    ) {
        viewModelScope.launch {
            repository.setNotificationSettings(callHandled, summaryReady, aiEvents, permissionReminders)
        }
    }

    fun setAppearanceMode(mode: String) {
        viewModelScope.launch {
            repository.setAppearanceMode(mode)
        }
    }

    fun setRetainVoiceData(retain: Boolean) {
        viewModelScope.launch {
            repository.setRetainVoiceData(retain)
        }
    }

    // Live AI Call Handling & Session Execution
    fun startLiveAiCall(
        callerNumber: String = "+1 (555) 019-2834",
        callerName: String = "Incoming Caller",
        isSimulated: Boolean = false
    ) {
        callAssistantManager.startAiCallHandling(callerNumber, callerName, isSimulated)
    }

    fun transferCallToUser() {
        callAssistantManager.transferCallToUser()
    }

    fun endCallSession() {
        callAssistantManager.endCallSession()
    }

    fun toggleCallMute() {
        callAssistantManager.toggleMute()
    }

    fun toggleCallSpeaker() {
        callAssistantManager.toggleSpeaker()
    }

    fun simulateCallerSpeech(utterance: String) {
        callAssistantManager.handleCallerSpokenUtterance(utterance)
    }

    fun simulateIncomingCall(phoneNumber: String = "+1 (555) 019-2834") {
        _simulatedCallerNumber.value = phoneNumber
        _simulatedScreeningDialog.value = true
        callAssistantManager.handleIncomingCallDetected(
            phoneNumber = phoneNumber,
            state = "RINGING",
            isSimulated = true
        )
    }

    fun dismissSimulatedCall() {
        _simulatedScreeningDialog.value = false
    }

    fun deleteCallRecord(id: Long) {
        viewModelScope.launch {
            repository.deleteCallEvent(id)
        }
    }

    fun clearAllCallRecords() {
        viewModelScope.launch {
            repository.clearCallEvents()
        }
    }

    val authManager = com.example.auth.AuthManager()

    fun onPhoneVerified(userId: String, phoneNumber: String, countryCode: String = "+91") {
        viewModelScope.launch {
            repository.setUserAuthenticated(phoneNumber, countryCode, userId)
        }
    }

    fun setUserProfile(name: String, avatar: String) {
        viewModelScope.launch {
            repository.setUserProfile(name, avatar)
        }
    }

    fun logout() {
        viewModelScope.launch {
            repository.logout()
        }
    }

    fun deleteAccount() {
        viewModelScope.launch {
            repository.deleteAccount()
        }
    }

    fun deleteCallSummary(id: Long) {
        viewModelScope.launch {
            repository.clearCallSummary(id)
        }
    }

    fun deleteCallTranscript(id: Long) {
        viewModelScope.launch {
            repository.clearCallTranscript(id)
        }
    }

    fun clearAllCallSummaries() {
        viewModelScope.launch {
            repository.clearAllCallSummaries()
        }
    }

    fun clearAllCallTranscripts() {
        viewModelScope.launch {
            repository.clearAllCallTranscripts()
        }
    }
}

class MainViewModelFactory(
    private val repository: EquiliRepository,
    private val aiEngine: EquiliAIEngine,
    private val callAssistantManager: CallAssistantManager,
    private val voiceManager: VoiceManager,
    private val ttsManager: TextToSpeechManager
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            return MainViewModel(repository, aiEngine, callAssistantManager, voiceManager, ttsManager) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
