package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.EquiliTopBar
import com.example.ui.theme.EquiliError
import com.example.ui.theme.EquiliNeonCyan
import com.example.ui.theme.EquiliPrimary
import com.example.ui.theme.EquiliSuccess
import com.example.ui.theme.EquiliWarning
import com.example.ui.viewmodel.MainViewModel

@Composable
fun PrivacyScreen(
    viewModel: MainViewModel,
    onBackClick: () -> Unit,
    onLogout: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val prefs = uiState.preferences
    val scrollState = rememberScrollState()

    var showClearHistoryConfirm by remember { mutableStateOf(false) }
    var showClearTranscriptsConfirm by remember { mutableStateOf(false) }
    var showClearSummariesConfirm by remember { mutableStateOf(false) }
    var showClearChatConfirm by remember { mutableStateOf(false) }
    var showDeleteAccountConfirm by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize()
        ) {
            EquiliTopBar(
                title = "Privacy & Data Governance",
                onBackClick = onBackClick
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp)
                    .verticalScroll(scrollState),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(16.dp))

                // Hero Shield Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = EquiliPrimary.copy(alpha = 0.12f)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(EquiliPrimary.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = EquiliNeonCyan,
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column {
                            Text(
                                text = "Zero Secret Recordings",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = "EquiliAI Max never secretly records audio. All data remains encrypted on your local device.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Section 1: Privacy Policies & Guarantees
                Text(
                    text = "Core Privacy Commitments",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                PrivacyCommitmentItem(
                    icon = Icons.Default.MicOff,
                    title = "No Default Call Recording",
                    description = "Call audio is processed transiently for speech-to-text. Raw audio files are never stored or uploaded."
                )

                Spacer(modifier = Modifier.height(8.dp))

                PrivacyCommitmentItem(
                    icon = Icons.Default.Lock,
                    title = "Opt-In Transcripts Only",
                    description = "Text transcripts of phone conversations are disabled unless you explicitly grant affirmative consent."
                )

                Spacer(modifier = Modifier.height(8.dp))

                PrivacyCommitmentItem(
                    icon = Icons.Default.Security,
                    title = "Strict Android Security Compliance",
                    description = "No accessibility backdoors, root exploits, or hidden call tapping. We adhere strictly to standard Android telecom guidelines."
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Section 2: Storage & Consent Settings
                Text(
                    text = "Consent & Storage Settings",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Toggle 1: Save Transcripts Consent
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Save Call Transcripts",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Store textual transcript of AI-handled conversations locally on this device.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = prefs.saveTranscriptsConsent,
                                onCheckedChange = { viewModel.setSaveTranscriptsConsent(it) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = EquiliPrimary
                                ),
                                modifier = Modifier.testTag("privacy_transcripts_switch")
                            )
                        }

                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 12.dp),
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                        )

                        // Toggle 2: Generate AI Summaries
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Generate AI Call Summaries",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Analyze call purpose and extract action items for incoming screened calls.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = prefs.generateAiSummaries,
                                onCheckedChange = { viewModel.setGenerateAiSummaries(it) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = EquiliPrimary
                                ),
                                modifier = Modifier.testTag("privacy_summaries_switch")
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Section 3: Data Deletion & Purge Controls
                Text(
                    text = "Data Management & Deletion",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "You maintain complete ownership of all recorded call metadata, transcripts, and summaries. Use the actions below to permanently purge stored records.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        // Action 1: Delete Transcripts
                        OutlinedButton(
                            onClick = { showClearTranscriptsConfirm = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("privacy_delete_transcripts_btn"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = EquiliWarning
                            )
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Delete All Stored Transcripts")
                        }

                        // Action 2: Delete Summaries
                        OutlinedButton(
                            onClick = { showClearSummariesConfirm = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("privacy_delete_summaries_btn"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = EquiliWarning
                            )
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Delete All AI Call Summaries")
                        }

                        // Action 3: Clear Chat History
                        OutlinedButton(
                            onClick = { showClearChatConfirm = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("privacy_clear_chat_btn"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = EquiliWarning
                            )
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Clear Chat History (${uiState.chatMessages.size} messages)")
                        }

                        // Action 4: Clear All Call History
                        Button(
                            onClick = { showClearHistoryConfirm = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("privacy_clear_all_history_btn"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = EquiliError.copy(alpha = 0.85f),
                                contentColor = Color.White
                            )
                        ) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Clear Entire Call History (${uiState.callEvents.size} records)")
                        }

                        // Action 5: Delete Account & Wipe Everything
                        Button(
                            onClick = { showDeleteAccountConfirm = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("privacy_delete_account_btn"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = EquiliError,
                                contentColor = Color.White
                            )
                        ) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Delete Account & Wipe Device Data")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }

    // Confirmation Dialogs
    if (showClearTranscriptsConfirm) {
        AlertDialog(
            onDismissRequest = { showClearTranscriptsConfirm = false },
            title = { Text("Delete All Transcripts?") },
            text = { Text("This will permanently erase all stored conversational dialogue transcripts. Call metadata and durations will remain.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearAllCallTranscripts()
                        showClearTranscriptsConfirm = false
                    }
                ) {
                    Text("Delete Transcripts", color = EquiliWarning)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearTranscriptsConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showClearSummariesConfirm) {
        AlertDialog(
            onDismissRequest = { showClearSummariesConfirm = false },
            title = { Text("Delete All Call Summaries?") },
            text = { Text("This will permanently remove all generated call summaries, action items, and caller reasons.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearAllCallSummaries()
                        showClearSummariesConfirm = false
                    }
                ) {
                    Text("Delete Summaries", color = EquiliWarning)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearSummariesConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showClearHistoryConfirm) {
        AlertDialog(
            onDismissRequest = { showClearHistoryConfirm = false },
            title = { Text("Clear Entire Call History?") },
            text = { Text("This will permanently delete all call screening records, logs, summaries, and transcripts. This action cannot be undone.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearAllCallRecords()
                        showClearHistoryConfirm = false
                    }
                ) {
                    Text("Clear All", color = EquiliError)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearHistoryConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showClearChatConfirm) {
        AlertDialog(
            onDismissRequest = { showClearChatConfirm = false },
            title = { Text("Clear Chat History?") },
            text = { Text("This will permanently delete all conversational chat messages stored in the local database.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearChat()
                        showClearChatConfirm = false
                    }
                ) {
                    Text("Clear Chat", color = EquiliWarning, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearChatConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showDeleteAccountConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteAccountConfirm = false },
            title = { Text("Permanently Delete Account?") },
            text = { Text("This will erase all profile data, conversation transcripts, call events, and local preferences from this device. You will be logged out and returned to the setup screen.") },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteAccountConfirm = false
                        viewModel.deleteAccount()
                        onLogout()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EquiliError)
                ) {
                    Text("Delete Everything")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAccountConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun PrivacyCommitmentItem(
    icon: ImageVector,
    title: String,
    description: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(EquiliSuccess.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = EquiliSuccess,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 16.sp
                )
            }
        }
    }
}
