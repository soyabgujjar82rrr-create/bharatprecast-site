package com.example.ui.screens

import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.permissions.PermissionHelper
import com.example.permissions.PermissionType
import com.example.ui.components.EquiliTopBar
import com.example.ui.components.PermissionCardComponent
import com.example.ui.theme.EquiliPrimary
import com.example.ui.viewmodel.MainViewModel

@Composable
fun PermissionsSetupScreen(
    viewModel: MainViewModel,
    onCompleteSetup: () -> Unit,
    onBackClick: (() -> Unit)? = null,
    buttonTitle: String = "Continue to AI Assistant Setup",
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val scrollState = rememberScrollState()

    // Refresh permissions on screen entrance
    LaunchedEffect(Unit) {
        viewModel.updatePermissionStatuses(context)
    }

    // Permission Launchers
    val micLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        viewModel.updatePermissionStatuses(context)
    }

    val notifLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        viewModel.updatePermissionStatuses(context)
    }

    val phoneLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        viewModel.updatePermissionStatuses(context)
    }

    val contactsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        viewModel.updatePermissionStatuses(context)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize()
        ) {
            EquiliTopBar(
                title = "Permission Center",
                onBackClick = onBackClick
            )

            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 24.dp)
                    .verticalScroll(scrollState),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Device Permissions & Privacy",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "EquiliAI Max only requests permissions strictly required for voice interactions and call screening. Each permission status is shown below as Granted, Not Granted, or Not Supported.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Permission Cards
                    uiState.permissionStatuses.forEach { item ->
                        PermissionCardComponent(
                            item = item,
                            onRequestClick = {
                                when (item.type) {
                                    PermissionType.MICROPHONE -> micLauncher.launch(item.type.permissionManifest)
                                    PermissionType.NOTIFICATIONS -> {
                                        if (item.type.permissionManifest.isNotEmpty()) {
                                            notifLauncher.launch(item.type.permissionManifest)
                                        }
                                    }
                                    PermissionType.PHONE_STATE -> phoneLauncher.launch(item.type.permissionManifest)
                                    PermissionType.CONTACTS -> contactsLauncher.launch(item.type.permissionManifest)
                                }
                            },
                            onOpenSettingsClick = {
                                PermissionHelper.openAppSettings(context)
                            }
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                    }
                }

                // Completion CTAs
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp, bottom = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Button(
                        onClick = onCompleteSetup,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("permissions_complete_setup_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EquiliPrimary,
                            contentColor = Color.White
                        )
                    ) {
                        Text(
                            text = buttonTitle,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    TextButton(
                        onClick = onCompleteSetup,
                        modifier = Modifier.testTag("permissions_skip_limited_button")
                    ) {
                        Text(
                            text = "Continue with Current Privileges",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
