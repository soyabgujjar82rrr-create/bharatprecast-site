package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.EquiliTopBar
import com.example.ui.theme.EquiliNeonCyan
import com.example.ui.theme.EquiliPrimary
import com.example.ui.theme.EquiliSuccess

@Composable
fun AboutScreen(
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showApkDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize()
        ) {
            EquiliTopBar(
                title = "About EquiliAI Max",
                onBackClick = onBackClick
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                item {
                    Spacer(modifier = Modifier.height(10.dp))

                    // App Brand Banner
                    Image(
                        painter = painterResource(id = R.drawable.equiliai_logo),
                        contentDescription = "EquiliAI Logo",
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "EquiliAI Max",
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Text(
                        text = "Version 1.0.0 • Build 2026.10",
                        style = MaterialTheme.typography.bodySmall,
                        color = EquiliNeonCyan
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Next-Generation AI Voice, Call Screening & Chat Intelligence",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Prominent Download APK Button
                    Button(
                        onClick = { showApkDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("btn_download_apk"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EquiliPrimary,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = "Download APK",
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Download EquiliAI Max APK (24 MB)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Section 1: Privacy Policy
                item {
                    LegalAccordionCard(
                        icon = Icons.Default.Policy,
                        title = "Privacy Policy",
                        subtitle = "Zero secret recordings, encrypted local persistence",
                        content = """
                            EquiliAI Max respects user privacy as a foundational principle:
                            • Zero Secret Recordings: We never secretly record, store, or transmit incoming or outgoing carrier call audio.
                            • Transcripts by Consent Only: Call transcripts are transcribed transiently in memory for real-time screening. Text transcripts are saved locally only if you explicitly enable transcript consent.
                            • No Cloud Audio Storage: Speech processing via native Android SpeechRecognizer and Gemini APIs processes text tokens transiently without persisting raw audio.
                            • Local Database Security: Chat history, user preferences, and screening records are stored in an encrypted Room SQLite database residing strictly in your device's protected app sandbox.
                            • Complete Data Deletion: You can purge chat history, delete call transcripts, or delete your entire account and wipe all local records at any time.
                        """.trimIndent()
                    )
                }

                // Section 2: Terms of Service
                item {
                    LegalAccordionCard(
                        icon = Icons.Default.Gavel,
                        title = "Terms of Service",
                        subtitle = "Permitted usage, emergency calling, and boundaries",
                        content = """
                            By using EquiliAI Max, you agree to the following terms:
                            • Emergency Calling: EquiliAI Max is NOT a replacement for emergency telephone services (911/112). In any emergency situation, dial your official emergency services directly via your native phone dialer.
                            • Automated Assistance: AI voice responses and call screening summaries are generated using advanced neural language models. While designed for high accuracy, users should verify critical information independently.
                            • Android OS Compliance: Call answering and screening features conform strictly to official Android Telephony and Telecom APIs. EquiliAI Max does not bypass carrier restrictions or manufacturer security sandboxes.
                            • Lawful Use: You agree to use EquiliAI Max in compliance with all applicable local, national, and international laws regarding telecommunications, recording consent, and communication privacy.
                        """.trimIndent()
                    )
                }

                // Section 3: Open-Source Licenses
                item {
                    LegalAccordionCard(
                        icon = Icons.Default.Code,
                        title = "Open-Source Licenses",
                        subtitle = "Libraries, dependencies, and open licenses",
                        content = """
                            EquiliAI Max is built with gratitude to the open-source community:
                            • Jetpack Compose & Material 3 (Apache License 2.0)
                            • Kotlin & Kotlinx Coroutines (Apache License 2.0)
                            • AndroidX Room Persistence (Apache License 2.0)
                            • Square Retrofit, OkHttp & Moshi (Apache License 2.0)
                            • AndroidX Core, Lifecycle & Activity KTX (Apache License 2.0)
                            • Google Material Symbols & Roboto Fonts (Apache 2.0 / OFL)
                        """.trimIndent()
                    )
                }

                // Section 4: System Architecture
                item {
                    LegalAccordionCard(
                        icon = Icons.Default.Psychology,
                        title = "AI Architecture & Intelligence",
                        subtitle = "Hybrid cloud reasoning with on-device fallback",
                        content = """
                            • Cloud Engine: Connects to Google Gemini 2.5 Flash via encrypted REST endpoints using keys managed securely via AI Studio.
                            • On-Device Engine: Seamlessly switches to an on-device rule-based neural assistant whenever network connectivity is lost, ensuring hands-free voice assistance is always operational.
                            • Multi-Language Core: Engineered from the ground up for native English, हिन्दी (Hindi), and conversational Hinglish.
                        """.trimIndent()
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(28.dp))
                }
            }
        }

        // APK Download & Installation Details Dialog
        if (showApkDialog) {
            AlertDialog(
                onDismissRequest = { showApkDialog = false },
                icon = {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = null,
                        tint = EquiliNeonCyan,
                        modifier = Modifier.size(36.dp)
                    )
                },
                title = {
                    Text(
                        text = "Download EquiliAI Max APK",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Build Status: Successful (Release Debug)",
                            fontWeight = FontWeight.Bold,
                            color = EquiliSuccess,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "• Package: com.aistudio.equiliaimax.krzxqe\n• File Size: ~24 MB\n• Binary: app-debug.apk\n• Path: app/build/outputs/apk/debug/app-debug.apk",
                            style = MaterialTheme.typography.bodySmall,
                            lineHeight = 18.sp
                        )
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                        Text(
                            text = "Direct Download Options in AI Studio:\n1. Open the top-right toolbar menu (⋮).\n2. Select 'Download APK' or 'Export Project' to save the APK to your device.\n3. Install directly on any Android 8.0+ device.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 18.sp
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { showApkDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = EquiliPrimary)
                    ) {
                        Text("Got It")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showApkDialog = false }) {
                        Text("Close")
                    }
                }
            )
        }
    }
}

@Composable
private fun LegalAccordionCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    content: String
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { expanded = !expanded },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(EquiliPrimary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = EquiliNeonCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        )
                    }
                }

                Icon(
                    imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = EquiliPrimary
                )
            }

            AnimatedVisibility(visible = expanded) {
                Column {
                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = content,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 20.sp
                    )
                }
            }
        }
    }
}
