package com.example.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.callassistant.AiVoiceProfiles
import com.example.permissions.PermissionHelper
import com.example.ui.components.ChatMessageBubble
import com.example.ui.components.EquiliTopBar
import com.example.ui.components.TypingIndicatorBubble
import com.example.ui.components.VoiceWaveVisualizer
import com.example.ui.theme.EquiliError
import com.example.ui.theme.EquiliNeonCyan
import com.example.ui.theme.EquiliNeonPurple
import com.example.ui.theme.EquiliPrimary
import com.example.ui.theme.EquiliSuccess
import com.example.ui.theme.EquiliWarning
import com.example.ui.viewmodel.MainViewModel
import com.example.voice.VoiceState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VoiceAssistantScreen(
    viewModel: MainViewModel,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val prefs = uiState.preferences
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    var showVoiceSettingsDialog by remember { mutableStateOf(false) }
    var showMemoryDialog by remember { mutableStateOf(false) }
    var showClearChatDialog by remember { mutableStateOf(false) }

    var hasMicPermission by remember {
        mutableStateOf(PermissionHelper.isPermissionGranted(context, Manifest.permission.RECORD_AUDIO))
    }

    val micLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasMicPermission = granted
        viewModel.updatePermissionStatuses(context)
        if (granted) {
            viewModel.startListening()
        }
    }

    // Auto-scroll when messages update or when AI starts typing
    LaunchedEffect(uiState.chatMessages.size, uiState.isProcessingAi) {
        if (uiState.chatMessages.isNotEmpty()) {
            listState.animateScrollToItem(uiState.chatMessages.size - 1)
        }
    }

    val isListening = uiState.voiceState is VoiceState.Listening || uiState.voiceState is VoiceState.Ready
    val rmsDb = (uiState.voiceState as? VoiceState.Listening)?.rmsDb ?: 0f

    val quickSuggestions = listOf(
        "Explain call screening",
        "What can you do?",
        "नमस्ते, आप क्या कर सकते हैं?",
        "Help me draft an email",
        "Tips for focus & productivity"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize()
                .navigationBarsPadding()
                .imePadding()
        ) {
            // Screen Top Bar with Model Status and Action Controls
            EquiliTopBar(
                title = "AI Chat & Voice",
                onBackClick = onBackClick,
                actions = {
                    // Action 1: New Chat
                    IconButton(
                        onClick = { viewModel.startNewChat() },
                        modifier = Modifier.testTag("chat_new_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddComment,
                            contentDescription = "New Chat",
                            tint = EquiliNeonCyan
                        )
                    }

                    // Action 2: AI Memory Sheet
                    IconButton(
                        onClick = { showMemoryDialog = true },
                        modifier = Modifier.testTag("chat_memory_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Psychology,
                            contentDescription = "AI Memory Settings",
                            tint = if (prefs.aiMemoryEnabled) EquiliPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Action 3: Voice Settings
                    IconButton(
                        onClick = { showVoiceSettingsDialog = true },
                        modifier = Modifier.testTag("chat_voice_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Voice Settings",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Action 4: Clear Chat (if not empty)
                    if (uiState.chatMessages.isNotEmpty()) {
                        IconButton(
                            onClick = { showClearChatDialog = true },
                            modifier = Modifier.testTag("chat_clear_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteSweep,
                                contentDescription = "Clear Chat",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            )

            // Model Status Strip & Active Audio Controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Engine Status Pill
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(if (uiState.isCloudConfigured) EquiliSuccess else EquiliNeonCyan)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (uiState.isCloudConfigured) "Gemini 2.5 Flash Active" else "Local Neural Assistant",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Stop Speech Control (when AI is speaking aloud)
                if (uiState.isSpeaking) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(EquiliError.copy(alpha = 0.2f))
                            .clickable { viewModel.stopSpeaking() }
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                            .testTag("btn_stop_speaking")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.VolumeOff,
                            contentDescription = "Stop Speech",
                            tint = EquiliError,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Stop Audio",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = EquiliError
                        )
                    }
                } else if (prefs.aiMemoryEnabled) {
                    Text(
                        text = "Memory: ${uiState.memoryTurnCount} turns",
                        fontSize = 11.sp,
                        color = EquiliPrimary
                    )
                }
            }

            // Live Listening Active Audio Wave Bar
            AnimatedVisibility(visible = isListening) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = EquiliNeonCyan.copy(alpha = 0.12f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            VoiceWaveVisualizer(
                                isListening = true,
                                isProcessing = false,
                                rmsDb = rmsDb,
                                modifier = Modifier.size(width = 60.dp, height = 24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "Listening... Speak naturally",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                color = EquiliNeonCyan
                            )
                        }

                        Button(
                            onClick = { viewModel.stopListening() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = EquiliPrimary,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("Done", fontSize = 11.sp)
                        }
                    }
                }
            }

            // Permission Warning Banner if mic is not granted
            val errorState = uiState.voiceState as? VoiceState.Error
            if (!hasMicPermission || errorState != null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = EquiliError.copy(alpha = 0.15f)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.ErrorOutline,
                            contentDescription = null,
                            tint = EquiliError,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (!hasMicPermission) {
                                "Microphone permission is required for voice recognition."
                            } else {
                                errorState?.message ?: "Voice recognition unavailable."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f),
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Button(
                            onClick = {
                                if (!hasMicPermission) {
                                    micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                } else {
                                    viewModel.startListening()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = EquiliError,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text(if (!hasMicPermission) "Grant" else "Retry", fontSize = 10.sp)
                        }
                    }
                }
            }

            // Chat Messages / Empty State Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                if (uiState.chatMessages.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 8.dp, vertical = 16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(EquiliPrimary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Psychology,
                                contentDescription = null,
                                tint = EquiliNeonCyan,
                                modifier = Modifier.size(34.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "How can I help you today?",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Type your query or tap the microphone to talk naturally in English or Hindi.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        // Quick Suggestion Chips
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            quickSuggestions.forEach { suggestion ->
                                SuggestionChip(
                                    onClick = { viewModel.processUserQuery(suggestion) },
                                    label = { Text(suggestion, fontSize = 12.sp) },
                                    colors = SuggestionChipDefaults.suggestionChipColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                                    ),
                                    shape = RoundedCornerShape(16.dp),
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(uiState.chatMessages, key = { it.id }) { message ->
                            ChatMessageBubble(
                                message = message,
                                onSpeakClick = { viewModel.speakText(it) },
                                onRetryClick = { viewModel.retryQuery(it) }
                            )
                        }

                        if (uiState.isProcessingAi) {
                            item {
                                TypingIndicatorBubble()
                            }
                        }
                    }
                }
            }

            // Bottom Input Bar: Text Field + Direct Mic + Send Button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Outlined Text Field
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = {
                        Text(
                            if (prefs.assistantLanguage == "hi") "यहाँ लिखें या बोलें..." else "Ask or speak anything...",
                            fontSize = 13.sp
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_text_input"),
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EquiliPrimary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                    ),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(
                        onSend = {
                            if (inputText.isNotBlank()) {
                                viewModel.processUserQuery(inputText)
                                inputText = ""
                            }
                        }
                    )
                )

                Spacer(modifier = Modifier.width(6.dp))

                // Microphone Button (Voice Assistant Input)
                IconButton(
                    onClick = {
                        if (isListening) {
                            viewModel.stopListening()
                        } else {
                            if (hasMicPermission) {
                                viewModel.startListening()
                            } else {
                                micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    },
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(
                            if (isListening) EquiliNeonCyan
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                        .testTag("chat_mic_button")
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                        contentDescription = if (isListening) "Stop Listening" else "Speak",
                        tint = if (isListening) Color.Black else EquiliPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Send Button (Appears or Highlights when user types)
                if (inputText.isNotBlank()) {
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                        onClick = {
                            if (inputText.isNotBlank()) {
                                viewModel.processUserQuery(inputText)
                                inputText = ""
                            }
                        },
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(EquiliPrimary)
                            .testTag("chat_send_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send Message",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }

    // Dialog 1: Voice Settings Dialog
    if (showVoiceSettingsDialog) {
        VoiceSettingsDialog(
            viewModel = viewModel,
            currentLanguage = prefs.assistantLanguage,
            currentVoiceId = prefs.aiVoiceId,
            currentRate = prefs.speechRate,
            currentPitch = prefs.speechPitch,
            autoSpeakEnabled = prefs.autoSpeakEnabled,
            onDismiss = { showVoiceSettingsDialog = false }
        )
    }

    // Dialog 2: AI Memory Settings Dialog
    if (showMemoryDialog) {
        AiMemoryDialog(
            viewModel = viewModel,
            memoryEnabled = prefs.aiMemoryEnabled,
            memoryTurnCount = uiState.memoryTurnCount,
            totalMessages = uiState.chatMessages.size,
            onDismiss = { showMemoryDialog = false }
        )
    }

    // Dialog 3: Delete Chat Confirmation
    if (showClearChatDialog) {
        AlertDialog(
            onDismissRequest = { showClearChatDialog = false },
            title = { Text("Delete Entire Conversation?") },
            text = { Text("All messages and context will be permanently cleared from this device.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearChat()
                        showClearChatDialog = false
                    }
                ) {
                    Text("Delete All", color = EquiliError, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearChatDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun VoiceSettingsDialog(
    viewModel: MainViewModel,
    currentLanguage: String,
    currentVoiceId: String,
    currentRate: Float,
    currentPitch: Float,
    autoSpeakEnabled: Boolean,
    onDismiss: () -> Unit
) {
    var selectedLanguage by remember { mutableStateOf(currentLanguage) }
    var selectedVoiceId by remember { mutableStateOf(currentVoiceId) }
    var speechRate by remember { mutableFloatStateOf(currentRate) }
    var autoSpeak by remember { mutableStateOf(autoSpeakEnabled) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Tune, contentDescription = null, tint = EquiliPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Voice & Speech Settings", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Auto-speak Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Auto-Speak Responses", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold))
                        Text("Read AI answers aloud using TTS", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = autoSpeak,
                        onCheckedChange = { autoSpeak = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = EquiliPrimary)
                    )
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                // Language Selection
                Text("Language Mode", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    LanguageChip("English", "en", selectedLanguage == "en") { selectedLanguage = "en" }
                    LanguageChip("हिन्दी", "hi", selectedLanguage == "hi") { selectedLanguage = "hi" }
                    LanguageChip("Hinglish", "hinglish", selectedLanguage == "hinglish") { selectedLanguage = "hinglish" }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                // Speaking Speed Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Speaking Speed", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold))
                    Text("${String.format("%.2f", speechRate)}x", color = EquiliPrimary, fontWeight = FontWeight.Bold)
                }

                Slider(
                    value = speechRate,
                    onValueChange = { speechRate = it },
                    valueRange = 0.75f..1.5f,
                    colors = SliderDefaults.colors(thumbColor = EquiliPrimary, activeTrackColor = EquiliPrimary)
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                // AI Voice Personality
                Text("AI Voice Personality", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold))

                AiVoiceProfiles.ALL.forEach { voice ->
                    val isSelected = selectedVoiceId == voice.id
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { selectedVoiceId = voice.id }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = isSelected,
                            onClick = { selectedVoiceId = voice.id },
                            colors = RadioButtonDefaults.colors(selectedColor = EquiliPrimary)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(voice.name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                            Text(voice.description, style = MaterialTheme.typography.bodySmall, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(
                            onClick = {
                                viewModel.setAiVoiceId(voice.id)
                                viewModel.speakText("Hello, this is ${voice.name}.")
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = "Preview Voice", tint = EquiliPrimary, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    viewModel.setLanguage(selectedLanguage)
                    viewModel.setAiVoiceId(selectedVoiceId)
                    viewModel.setAutoSpeak(autoSpeak)
                    viewModel.setVoiceRateAndPitch(speechRate, currentPitch)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = EquiliPrimary)
            ) {
                Text("Save Settings")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun AiMemoryDialog(
    viewModel: MainViewModel,
    memoryEnabled: Boolean,
    memoryTurnCount: Int,
    totalMessages: Int,
    onDismiss: () -> Unit
) {
    var isEnabled by remember { mutableStateOf(memoryEnabled) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Psychology, contentDescription = null, tint = EquiliPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("AI Conversation Memory", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Toggle Memory
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Enable AI Memory", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold))
                        Text("Remembers recent turns so you can ask natural follow-up questions.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = isEnabled,
                        onCheckedChange = {
                            isEnabled = it
                            viewModel.setAiMemoryEnabled(it)
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = EquiliPrimary)
                    )
                }

                // Memory Status
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(10.dp)
                ) {
                    Text(
                        text = if (isEnabled) "Active: Remembering $memoryTurnCount dialogue turns in session ($totalMessages stored)." else "Memory disabled: Each prompt is processed independently.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                // Action 1: Clear Memory Buffer
                OutlinedButton(
                    onClick = {
                        viewModel.clearConversationMemory()
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Clear Memory Buffer (Keep Chat)")
                }

                // Action 2: New Conversation
                Button(
                    onClick = {
                        viewModel.startNewChat()
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EquiliPrimary)
                ) {
                    Icon(Icons.Default.AddComment, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Start New Conversation")
                }

                // Action 3: Delete Entire Chat
                OutlinedButton(
                    onClick = {
                        viewModel.clearChat()
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = EquiliError)
                ) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Delete Entire Chat History")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
private fun LanguageChip(
    label: String,
    code: String,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) EquiliPrimary else MaterialTheme.colorScheme.surfaceVariant)
            .clickable { onSelect() }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
        )
    }
}
