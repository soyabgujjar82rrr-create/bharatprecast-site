package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.ui.theme.EquiliNeonCyan
import com.example.ui.theme.EquiliNeonPurple
import com.example.ui.theme.EquiliPrimary
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun VoiceWaveVisualizer(
    isListening: Boolean,
    isProcessing: Boolean,
    rmsDb: Float,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_transition")

    val pulsePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_phase"
    )

    val scaleMultiplier = if (isListening) {
        (1.0f + (rmsDb.coerceIn(0f, 15f) / 12f))
    } else if (isProcessing) {
        1.15f
    } else {
        1.0f
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val baseRadius = (size.minDimension / 2f) * 0.45f

        // Draw multiple glowing rings
        val ringsCount = 4
        for (i in 1..ringsCount) {
            val ringProgress = (i.toFloat() / ringsCount)
            val ringWave = if (isListening || isProcessing) {
                sin(pulsePhase + (i * 0.8f)) * 8f * scaleMultiplier
            } else {
                sin(pulsePhase + (i * 0.5f)) * 3f
            }
            val radius = (baseRadius * ringProgress * scaleMultiplier) + ringWave

            val ringColor = when (i) {
                1 -> EquiliNeonCyan.copy(alpha = 0.8f)
                2 -> EquiliPrimary.copy(alpha = 0.6f)
                3 -> EquiliNeonPurple.copy(alpha = 0.4f)
                else -> EquiliNeonCyan.copy(alpha = 0.2f)
            }

            drawCircle(
                color = ringColor,
                radius = radius.coerceAtLeast(10f),
                center = center,
                style = Stroke(width = 3.5f)
            )
        }

        // Center orb with gradient
        val orbRadius = baseRadius * 0.4f * (if (isListening) 1.1f else 1.0f)
        val orbBrush = Brush.radialGradient(
            colors = listOf(
                EquiliNeonCyan,
                EquiliPrimary,
                EquiliNeonPurple.copy(alpha = 0.7f)
            ),
            center = center,
            radius = orbRadius
        )

        drawCircle(
            brush = orbBrush,
            radius = orbRadius,
            center = center
        )
    }
}
