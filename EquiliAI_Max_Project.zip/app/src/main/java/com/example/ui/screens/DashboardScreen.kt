package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.StatusBadge
import com.example.ui.theme.EquiliNeonCyan
import com.example.ui.theme.EquiliNeonPurple
import com.example.ui.theme.EquiliPrimary
import com.example.ui.theme.EquiliSuccess
import com.example.ui.theme.EquiliWarning
import com.example.ui.viewmodel.MainViewModel

@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    onNavigateToVoice: () -> Unit,
    onNavigateToCall: () -> Unit,
    onNavigateToCallHistory: () -> Unit = onNavigateToCall,
    onNavigateToAccount: () -> Unit,
    onNavigateToPermissions: () -> Unit,
    onNavigateToPrivacy: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToAbout: () -> Unit,
    onNavigateToSetup: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val prefs = uiState.preferences
    val scrollState = rememberScrollState()

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val activeAvatar = AVATAR_OPTIONS.find { it.id == prefs.userAvatar } ?: AVATAR_OPTIONS.first()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize()
                .padding(horizontal = 20.dp)
                .verticalScroll(scrollState),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // User Profile & App Header Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clickable { onNavigateToAccount() }
                        .testTag("dashboard_profile_header")
                ) {
                    // Profile Avatar with colored ring
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(activeAvatar.color.copy(alpha = 0.2f))
                            .border(2.dp, activeAvatar.color, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "User Profile",
                            tint = activeAvatar.color,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = prefs.userName.ifBlank { "User" },
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.3.sp
                            ),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = prefs.userPhoneNumber.ifBlank { "EquiliAI Max" },
                            style = MaterialTheme.typography.bodySmall,
                            color = EquiliNeonCyan,
                            fontSize = 11.sp
                        )
                    }
                }

                // Master Toggle Switch
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (prefs.isAssistantEnabled) "Active" else "Paused",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                        color = if (prefs.isAssistantEnabled) EquiliSuccess else EquiliWarning,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                    Switch(
                        checked = prefs.isAssistantEnabled,
                        onCheckedChange = { viewModel.toggleAssistant(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = EquiliPrimary
                        ),
                        modifier = Modifier.testTag("dashboard_master_switch")
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Setup Status Card
            val isSetupComplete = prefs.isSetupCompleted
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (!isSetupComplete) onNavigateToSetup()
                    }
                    .testTag("dashboard_setup_status_card"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSetupComplete) {
                        EquiliSuccess.copy(alpha = 0.12f)
                    } else {
                        EquiliWarning.copy(alpha = 0.15f)
                    }
                )
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isSetupComplete) Icons.Default.CheckCircle else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (isSetupComplete) EquiliSuccess else EquiliWarning,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isSetupComplete) "Setup Complete & Verified" else "Setup Incomplete (Tap to Finish)",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (isSetupComplete) "Phone verified • Permissions active" else "Tap here to complete all setup steps.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Hero Quick Voice Action
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .clickable { onNavigateToVoice() }
                    .testTag("dashboard_start_voice_card"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Pulsing Mic Circle
                    Box(
                        modifier = Modifier
                            .size(86.dp)
                            .scale(if (prefs.isAssistantEnabled) pulseScale else 1.0f)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(EquiliNeonCyan, EquiliPrimary, EquiliNeonPurple)
                                )
                            )
                            .padding(4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(74.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.background),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Start Voice Assistant",
                                tint = EquiliNeonCyan,
                                modifier = Modifier.size(38.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "AI Chat & Voice Assistant",
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Tap to talk hands-free or type with EquiliAI",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    StatusBadge(
                        text = when (prefs.assistantLanguage) {
                            "hi" -> "हिन्दी Voice Mode"
                            "hinglish" -> "Hinglish Voice Mode"
                            else -> "English Voice Mode"
                        },
                        isSuccess = true
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "EquiliAI Max Features",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            )

            // 1. AI Assistant
            DashboardModuleCard(
                icon = Icons.Default.SmartToy,
                title = "AI Chat & Voice Intelligence",
                subtitle = "Conversational chat, Gemini reasoning, memory & speech",
                tag = "dashboard_nav_ai_assistant",
                onClick = onNavigateToVoice
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 2. AI Call Assistant
            DashboardModuleCard(
                icon = Icons.Default.Call,
                title = "AI Call Assistant",
                subtitle = if (prefs.isCallAssistantEnabled) "Call screening & response rules active" else "Call Assistant paused",
                tag = "dashboard_nav_call_assistant",
                onClick = onNavigateToCall
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 3. Call History
            DashboardModuleCard(
                icon = Icons.Default.History,
                title = "Call History & Summaries",
                subtitle = "${uiState.callEvents.size} recorded call screening events & transcripts",
                tag = "dashboard_nav_call_history",
                onClick = onNavigateToCallHistory
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 4. Voice Settings
            DashboardModuleCard(
                icon = Icons.Default.RecordVoiceOver,
                title = "Voice Settings",
                subtitle = "TTS pitch, speed, voice personality & auto-speak",
                tag = "dashboard_nav_voice_settings",
                onClick = onNavigateToSettings
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 5. Account
            DashboardModuleCard(
                icon = Icons.Default.Person,
                title = "Account Details",
                subtitle = "${prefs.userName.ifBlank { "User" }} • ${prefs.userPhoneNumber.ifBlank { "Verified" }}",
                tag = "dashboard_nav_account",
                onClick = onNavigateToAccount
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 6. Permissions Center
            DashboardModuleCard(
                icon = Icons.Default.Security,
                title = "Permission Center",
                subtitle = "Microphone, notifications, contacts & phone access status",
                tag = "dashboard_nav_permissions",
                onClick = onNavigateToPermissions
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 7. Privacy
            DashboardModuleCard(
                icon = Icons.Default.Lock,
                title = "Privacy & Data Governance",
                subtitle = "Zero unauthorized recordings, local encrypted storage",
                tag = "dashboard_nav_privacy",
                onClick = onNavigateToPrivacy
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 8. Settings
            DashboardModuleCard(
                icon = Icons.Default.Settings,
                title = "Settings",
                subtitle = "Language, voice parameters & master configuration",
                tag = "dashboard_nav_settings",
                onClick = onNavigateToSettings
            )

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
private fun DashboardModuleCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    tag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .testTag(tag),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(EquiliPrimary.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = EquiliNeonCyan,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
