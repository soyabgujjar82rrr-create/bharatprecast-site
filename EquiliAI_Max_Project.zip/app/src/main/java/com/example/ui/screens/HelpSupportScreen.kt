package com.example.ui.screens

import android.os.Build
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.EquiliTopBar
import com.example.ui.theme.EquiliNeonCyan
import com.example.ui.theme.EquiliPrimary
import com.example.ui.theme.EquiliSuccess
import com.example.ui.viewmodel.MainViewModel

@Composable
fun HelpSupportScreen(
    viewModel: MainViewModel,
    onBackClick: () -> Unit,
    onNavigateToPermissions: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val clipboardManager = LocalClipboardManager.current
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("FAQ", "Troubleshooting", "Permissions", "Contact")

    var showContactDialog by remember { mutableStateOf(false) }
    var contactSubject by remember { mutableStateOf("") }
    var contactMessage by remember { mutableStateOf("") }
    var showInquirySubmitted by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize()
        ) {
            EquiliTopBar(
                title = "Help & Support",
                onBackClick = onBackClick
            )

            // Category Tab Row
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = EquiliPrimary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = EquiliPrimary
                    )
                }
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 13.sp,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(10.dp))
                }

                when (selectedTab) {
                    0 -> {
                        // FAQ Section
                        item {
                            Text(
                                text = "Frequently Asked Questions",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Clear answers about EquiliAI Max capabilities and security standards.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        val faqItems = listOf(
                            "How does AI Call Screening work?" to "When an unknown call rings, EquiliAI Max provides an instant heads-up screening overlay. With your permission, the AI greets the caller, transcribes their response in real time, and produces a concise summary of the caller's intent.",
                            "Does EquiliAI Max record my phone conversations secretly?" to "Absolutely not. EquiliAI Max adheres strictly to zero-secret recording policies. No raw carrier audio is recorded or uploaded. Transcripts are only stored locally on your device if you explicitly enable the transcript consent toggle.",
                            "Can I talk in Hindi or Hinglish?" to "Yes. EquiliAI Max supports English, Hindi (हिन्दी), and Hinglish conversational input. Both speech recognition and Text-to-Speech adapt seamlessly to your chosen language.",
                            "How does AI Conversation Memory operate?" to "When AI Memory is enabled, recent conversation turns (up to 8 turns) are maintained in session context so you can ask natural follow-up questions. You can clear the memory buffer or turn it off anytime.",
                            "Does EquiliAI Max function without an active internet connection?" to "Yes! EquiliAI Max incorporates an on-device local rule-based intelligence engine that handles everyday queries, reminders, and call screening even when offline."
                        )

                        items(faqItems.size) { index ->
                            val (question, answer) = faqItems[index]
                            FaqExpandableCard(question = question, answer = answer)
                        }
                    }

                    1 -> {
                        // Troubleshooting Section
                        item {
                            Text(
                                text = "Diagnostic Troubleshooting",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Step-by-step solutions for common setup and runtime issues.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        val troubleshootItems = listOf(
                            TroubleshootItem(
                                title = "Voice Assistant Not Hearing My Voice",
                                cause = "Microphone permission is denied, or another application is holding audio focus.",
                                solution = "1. Verify Microphone permission in Permission Center.\n2. Ensure device microphone is not muted.\n3. Tap the microphone button in AI Chat & speak clearly."
                            ),
                            TroubleshootItem(
                                title = "AI Text-to-Speech is Silent",
                                cause = "Device media volume is muted or TTS engine is downloading voice files.",
                                solution = "1. Turn up Media Volume on your device.\n2. In Voice Settings, ensure 'Auto-Speak Responses' is turned ON.\n3. Tap 'Preview Voice' to test audio playback."
                            ),
                            TroubleshootItem(
                                title = "Incoming Call Screening Banner Did Not Appear",
                                cause = "Notification or Phone State permission missing, or device battery optimization killed background service.",
                                solution = "1. Check that Notification and Phone permissions are GRANTED.\n2. Verify that AI Call Assistant is turned ON in Settings.\n3. Note: Carrier-level automated call answering depends on Android manufacturer permissions."
                            ),
                            TroubleshootItem(
                                title = "Cloud AI Model Error / Offline Mode Active",
                                cause = "No internet connection or Gemini API key is missing from Secrets.",
                                solution = "1. Check your Wi-Fi or mobile data connectivity.\n2. EquiliAI automatically activates on-device local neural engine.\n3. For cloud features, add your Gemini API Key in AI Studio Secrets panel."
                            )
                        )

                        items(troubleshootItems.size) { index ->
                            TroubleshootCard(item = troubleshootItems[index])
                        }
                    }

                    2 -> {
                        // Permissions Help Section
                        item {
                            Text(
                                text = "Android Permission Governance",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Why EquiliAI Max requests specific permissions and how they protect your data.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        item {
                            PermissionExplainerCard(
                                title = "Microphone (RECORD_AUDIO)",
                                importance = "Essential for Voice AI",
                                explanation = "Used strictly when you tap the microphone button or during an active screening dialogue. Never listens in the background without user initiation."
                            )
                        }

                        item {
                            PermissionExplainerCard(
                                title = "Notifications (POST_NOTIFICATIONS)",
                                importance = "Essential for Call Alerts",
                                explanation = "Delivers timely heads-up alerts when incoming calls are detected, when AI call summaries are ready, and for permission reminders."
                            )
                        }

                        item {
                            PermissionExplainerCard(
                                title = "Contacts (READ_CONTACTS)",
                                importance = "Optional Convenience",
                                explanation = "Resolves incoming phone numbers into familiar contact names so you immediately know who is calling. Contacts are never uploaded to any remote server."
                            )
                        }

                        item {
                            PermissionExplainerCard(
                                title = "Phone State (READ_PHONE_STATE)",
                                importance = "Required for Screening",
                                explanation = "Detects ringing and incoming caller numbers to trigger real-time AI call screening options."
                            )
                        }

                        item {
                            Button(
                                onClick = onNavigateToPermissions,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("help_open_permissions_button"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = EquiliPrimary)
                            ) {
                                Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Open Permission Center")
                            }
                        }
                    }

                    3 -> {
                        // Contact & Support Section
                        item {
                            Text(
                                text = "Contact & Technical Support",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Reach our support engineers or review on-device diagnostic tokens.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Column(modifier = Modifier.padding(18.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Email, contentDescription = null, tint = EquiliNeonCyan)
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text("Direct Support Ticket", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                                            Text("support@equiliai.app • 24/7 Response", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))

                                    Button(
                                        onClick = { showContactDialog = true },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = EquiliPrimary)
                                    ) {
                                        Text("Submit Support Request")
                                    }
                                }
                            }
                        }

                        item {
                            // System Diagnostic Token Card
                            val diagnosticInfo = """
                                EquiliAI Max v1.0.0
                                Android SDK: ${Build.VERSION.SDK_INT} (${Build.MODEL})
                                Auth Status: ${if (uiState.preferences.isAuthenticated) "Verified" else "Guest"}
                                Cloud Model: ${if (uiState.isCloudConfigured) "Gemini 2.5 Flash Active" else "Local Neural Fallback"}
                                Voice State: ${uiState.voiceState::class.simpleName}
                                Database: Room v5 (Local Sandbox)
                            """.trimIndent()

                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Build, contentDescription = null, tint = EquiliPrimary, modifier = Modifier.size(20.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("System Diagnostics", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                                        }

                                        IconButton(
                                            onClick = {
                                                clipboardManager.setText(AnnotatedString(diagnosticInfo))
                                            }
                                        ) {
                                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy Diagnostics", tint = EquiliNeonCyan, modifier = Modifier.size(18.dp))
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(MaterialTheme.colorScheme.background)
                                            .padding(12.dp)
                                    ) {
                                        Text(
                                            text = diagnosticInfo,
                                            fontSize = 11.sp,
                                            lineHeight = 16.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(28.dp))
                }
            }
        }

        // Contact Support Dialog
        if (showContactDialog) {
            AlertDialog(
                onDismissRequest = { showContactDialog = false },
                title = { Text("Contact Support") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Please describe the issue or question. We will review your diagnostics and follow up with you.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        OutlinedTextField(
                            value = contactSubject,
                            onValueChange = { contactSubject = it },
                            label = { Text("Subject") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = contactMessage,
                            onValueChange = { contactMessage = it },
                            label = { Text("Details / Error Description") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 3
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showContactDialog = false
                            showInquirySubmitted = true
                            contactSubject = ""
                            contactMessage = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EquiliPrimary)
                    ) {
                        Text("Send Request")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showContactDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }

        // Inquiry Submitted Dialog
        if (showInquirySubmitted) {
            AlertDialog(
                onDismissRequest = { showInquirySubmitted = false },
                icon = { Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EquiliSuccess, modifier = Modifier.size(36.dp)) },
                title = { Text("Support Inquiry Logged") },
                text = { Text("Ticket #EQ-84920 has been opened. Our engineering team has received your diagnostic report and will assist you shortly.") },
                confirmButton = {
                    Button(onClick = { showInquirySubmitted = false }) {
                        Text("Done")
                    }
                }
            )
        }
    }
}

@Composable
private fun FaqExpandableCard(question: String, answer: String) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { expanded = !expanded },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = question,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = EquiliPrimary
                )
            }

            AnimatedVisibility(visible = expanded) {
                Column {
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = answer,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 20.sp
                    )
                }
            }
        }
    }
}

data class TroubleshootItem(val title: String, val cause: String, val solution: String)

@Composable
private fun TroubleshootCard(item: TroubleshootItem) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(text = item.title, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.onSurface)
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = "Probable Cause: ${item.cause}", style = MaterialTheme.typography.bodySmall, color = EquiliNeonCyan, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = item.solution, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 18.sp)
        }
    }
}

@Composable
private fun PermissionExplainerCard(title: String, importance: String, explanation: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.onSurface)
                Text(text = importance, fontSize = 11.sp, color = EquiliPrimary, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = explanation, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 18.sp)
        }
    }
}
