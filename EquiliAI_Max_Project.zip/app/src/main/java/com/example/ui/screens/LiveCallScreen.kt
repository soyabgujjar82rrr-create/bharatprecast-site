package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.PhoneForwarded
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeMute
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.callassistant.CallSessionStatus
import com.example.callassistant.CallTranscriptTurn
import com.example.ui.components.VoiceWaveVisualizer
import com.example.ui.theme.EquiliError
import com.example.ui.theme.EquiliNeonCyan
import com.example.ui.theme.EquiliNeonPurple
import com.example.ui.theme.EquiliPrimary
import com.example.ui.theme.EquiliSuccess
import com.example.ui.theme.EquiliWarning
import com.example.ui.viewmodel.MainViewModel

@Composable
fun LiveCallScreen(
    viewModel: MainViewModel,
    onCallEnded: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val session = uiState.liveCallSession
    val listState = rememberLazyListState()
    var simulatedInput by remember { mutableStateOf("") }
    var showTranscript by remember { mutableStateOf(true) }

    // Auto scroll transcript
    LaunchedEffect(session.transcripts.size) {
        if (session.transcripts.isNotEmpty()) {
            listState.animateScrollToItem(session.transcripts.size - 1)
        }
    }

    // Auto navigate when call ends
    LaunchedEffect(session.status) {
        if (session.status == CallSessionStatus.ENDED && !session.isActive) {
            onCallEnded()
        }
    }

    val durationText = remember(session.durationSeconds) {
        val mins = session.durationSeconds / 60
        val secs = session.durationSeconds % 60
        String.format(java.util.Locale.US, "%02d:%02d", mins, secs)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize()
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Call Header
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 28.dp)
            ) {
                // Caller Avatar Orb
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(
                                    EquiliPrimary.copy(alpha = 0.4f),
                                    MaterialTheme.colorScheme.surfaceVariant
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = EquiliNeonCyan,
                        modifier = Modifier.size(44.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = session.callerName.ifBlank { "Incoming Caller" },
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )

                Text(
                    text = session.callerNumber.ifBlank { "+1 (555) 019-2834" },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = durationText,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                    color = EquiliNeonCyan
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Assistant Status Pill
                val statusText = when (session.status) {
                    CallSessionStatus.INCOMING_ALERT -> "Incoming Alert..."
                    CallSessionStatus.GREETING -> "Playing AI Greeting..."
                    CallSessionStatus.LISTENING_CALLER -> "Listening to Caller..."
                    CallSessionStatus.PROCESSING_AI -> "AI Formulating Response..."
                    CallSessionStatus.SPEAKING_AI -> "AI Speaking to Caller..."
                    CallSessionStatus.TRANSFERRED_TO_ME -> "Transferred to You (Manual Call)"
                    CallSessionStatus.ENDED -> "Call Completed"
                }

                val statusBg = when (session.status) {
                    CallSessionStatus.SPEAKING_AI -> EquiliPrimary
                    CallSessionStatus.LISTENING_CALLER -> EquiliNeonCyan
                    CallSessionStatus.TRANSFERRED_TO_ME -> EquiliSuccess
                    CallSessionStatus.PROCESSING_AI -> EquiliNeonPurple
                    else -> MaterialTheme.colorScheme.surfaceVariant
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(statusBg.copy(alpha = 0.2f))
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (session.status == CallSessionStatus.PROCESSING_AI) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(12.dp),
                                color = EquiliNeonPurple,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                        Text(
                            text = statusText,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = if (session.status == CallSessionStatus.SPEAKING_AI) EquiliPrimary else if (session.status == CallSessionStatus.LISTENING_CALLER) EquiliNeonCyan else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // Central Visualizer / Transcript Area
            Card(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Live Conversation Transcript",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (showTranscript) "Hide" else "Show",
                            style = MaterialTheme.typography.bodySmall.copy(color = EquiliPrimary),
                            modifier = Modifier
                                .clickable { showTranscript = !showTranscript }
                                .padding(4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (showTranscript) {
                        if (session.transcripts.isEmpty()) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Connecting audio & initiating greeting...",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        } else {
                            LazyColumn(
                                state = listState,
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                items(session.transcripts) { turn ->
                                    CallTranscriptItem(turn)
                                }
                            }
                        }
                    } else {
                        // Compact Audio Wave Visualizer when transcript is hidden
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            VoiceWaveVisualizer(
                                isListening = session.status == CallSessionStatus.LISTENING_CALLER,
                                isProcessing = session.status == CallSessionStatus.PROCESSING_AI,
                                rmsDb = if (session.status == CallSessionStatus.SPEAKING_AI) 12f else 4f
                            )
                        }
                    }
                }
            }

            // Simulated Caller Tester Box (Lets the user test conversation turns seamlessly)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "Caller Speech Simulator (Test Multi-Turn Dialogue):",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Preset quick responses for fast testing
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        QuickUtteranceChip("Is Alex free?", onSend = { viewModel.simulateCallerSpeech(it) })
                        QuickUtteranceChip("Urgent matter!", onSend = { viewModel.simulateCallerSpeech(it) })
                        QuickUtteranceChip("Need appointment", onSend = { viewModel.simulateCallerSpeech(it) })
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = simulatedInput,
                            onValueChange = { simulatedInput = it },
                            placeholder = { Text("Speak or type caller response...", fontSize = 12.sp) },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            shape = RoundedCornerShape(20.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = EquiliPrimary
                            ),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.width(6.dp))

                        IconButton(
                            onClick = {
                                if (simulatedInput.isNotBlank()) {
                                    viewModel.simulateCallerSpeech(simulatedInput)
                                    simulatedInput = ""
                                }
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(EquiliPrimary)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Send Caller Speech",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            // Bottom Call Action Controls
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Human Handoff ("Talk to Me" / "Transfer to Me") Button
                if (!session.isTransferredToUser) {
                    Button(
                        onClick = { viewModel.transferCallToUser() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("call_talk_to_me_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EquiliPrimary,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.PhoneForwarded,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Talk to Me (Transfer Call)",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(EquiliSuccess.copy(alpha = 0.15f))
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Call transferred to User. AI conversation paused.",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = EquiliSuccess
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Bottom Circular Control Buttons: Mute, End Call, Speaker
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Mute
                    IconButton(
                        onClick = { viewModel.toggleCallMute() },
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(
                                if (session.isMuted) EquiliWarning.copy(alpha = 0.3f)
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                    ) {
                        Icon(
                            imageVector = if (session.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                            contentDescription = "Mute",
                            tint = if (session.isMuted) EquiliWarning else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // End Call Button (Big Red Circle)
                    IconButton(
                        onClick = {
                            viewModel.endCallSession()
                            onCallEnded()
                        },
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(EquiliError)
                            .testTag("call_end_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CallEnd,
                            contentDescription = "End Call",
                            tint = Color.White,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    // Speaker
                    IconButton(
                        onClick = { viewModel.toggleCallSpeaker() },
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(
                                if (session.isSpeakerOn) EquiliPrimary.copy(alpha = 0.3f)
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                    ) {
                        Icon(
                            imageVector = if (session.isSpeakerOn) Icons.AutoMirrored.Filled.VolumeUp else Icons.AutoMirrored.Filled.VolumeMute,
                            contentDescription = "Speaker",
                            tint = if (session.isSpeakerOn) EquiliPrimary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickUtteranceChip(
    text: String,
    onSend: (String) -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(EquiliPrimary.copy(alpha = 0.15f))
            .clickable { onSend(text) }
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            fontSize = 10.sp,
            color = EquiliNeonCyan,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun CallTranscriptItem(turn: CallTranscriptTurn) {
    val isAssistant = turn.speaker.equals("assistant", ignoreCase = true)
    val isSystem = turn.speaker.equals("system", ignoreCase = true)

    if (isSystem) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 2.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = turn.text,
                style = MaterialTheme.typography.bodySmall,
                color = EquiliWarning,
                fontSize = 11.sp
            )
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalAlignment = if (isAssistant) Alignment.Start else Alignment.End
    ) {
        Text(
            text = if (isAssistant) "EquiliAI Max" else "Caller",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = if (isAssistant) EquiliNeonCyan else MaterialTheme.colorScheme.onSurfaceVariant
        )
        Box(
            modifier = Modifier
                .clip(
                    RoundedCornerShape(
                        topStart = 12.dp,
                        topEnd = 12.dp,
                        bottomStart = if (isAssistant) 2.dp else 12.dp,
                        bottomEnd = if (isAssistant) 12.dp else 2.dp
                    )
                )
                .background(
                    if (isAssistant) EquiliPrimary.copy(alpha = 0.3f)
                    else MaterialTheme.colorScheme.surfaceVariant
                )
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Text(
                text = turn.text,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
