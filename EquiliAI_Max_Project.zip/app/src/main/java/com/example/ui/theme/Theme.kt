package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = EquiliPrimary,
    onPrimary = EquiliOnPrimary,
    primaryContainer = EquiliPrimaryContainer,
    onPrimaryContainer = EquiliOnPrimaryContainer,
    secondary = EquiliSecondary,
    onSecondary = EquiliOnSecondary,
    secondaryContainer = EquiliSecondaryContainer,
    onSecondaryContainer = EquiliOnSecondaryContainer,
    tertiary = EquiliTertiary,
    onTertiary = EquiliOnTertiary,
    tertiaryContainer = EquiliTertiaryContainer,
    onTertiaryContainer = EquiliOnTertiaryContainer,
    background = EquiliDarkBackground,
    onBackground = EquiliDarkOnSurface,
    surface = EquiliDarkSurface,
    onSurface = EquiliDarkOnSurface,
    surfaceVariant = EquiliDarkSurfaceVariant,
    onSurfaceVariant = EquiliDarkOnSurfaceVariant,
    outline = EquiliDarkOutline,
    error = EquiliError
)

private val LightColorScheme = lightColorScheme(
    primary = EquiliPrimary,
    onPrimary = EquiliOnPrimary,
    primaryContainer = EquiliPrimaryContainer,
    onPrimaryContainer = EquiliOnPrimaryContainer,
    secondary = EquiliSecondary,
    onSecondary = EquiliOnSecondary,
    secondaryContainer = EquiliSecondaryContainer,
    onSecondaryContainer = EquiliOnSecondaryContainer,
    tertiary = EquiliTertiary,
    onTertiary = EquiliOnTertiary,
    tertiaryContainer = EquiliTertiaryContainer,
    onTertiaryContainer = EquiliOnTertiaryContainer,
    background = EquiliLightBackground,
    onBackground = EquiliLightOnSurface,
    surface = EquiliLightSurface,
    onSurface = EquiliLightOnSurface,
    surfaceVariant = EquiliLightSurfaceVariant,
    onSurfaceVariant = EquiliLightOnSurfaceVariant,
    outline = EquiliLightOutline,
    error = EquiliError
)

@Composable
fun EquiliAITheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep distinctive brand theme by default
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
