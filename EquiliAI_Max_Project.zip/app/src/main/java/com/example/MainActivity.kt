package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.notifications.NotificationHelper
import com.example.ui.screens.AboutScreen
import com.example.ui.screens.AccountScreen
import com.example.ui.screens.AssistantSetupScreen
import com.example.ui.screens.CallAssistantScreen
import com.example.ui.screens.CallAssistantSetupScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.HelpSupportScreen
import com.example.ui.screens.LanguageVoiceSetupScreen
import com.example.ui.screens.LiveCallScreen
import com.example.ui.screens.OtpVerificationScreen
import com.example.ui.screens.PermissionsSetupScreen
import com.example.ui.screens.PhoneLoginScreen
import com.example.ui.screens.PrivacyScreen
import com.example.ui.screens.ProfileSetupScreen
import com.example.ui.screens.SecurityScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SetupCompleteScreen
import com.example.ui.screens.VoiceAssistantScreen
import com.example.ui.theme.EquiliAITheme
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.MainViewModelFactory

enum class Screen {
    PHONE_LOGIN,
    OTP_VERIFICATION,
    PROFILE_SETUP,
    LANGUAGE_VOICE_SETUP,
    PERMISSION_CENTER,
    AI_ASSISTANT_SETUP,
    CALL_ASSISTANT_SETUP,
    SETUP_COMPLETE,
    DASHBOARD,
    VOICE_ASSISTANT,
    CALL_ASSISTANT,
    CALL_HISTORY,
    LIVE_CALL,
    ACCOUNT,
    SETTINGS,
    PRIVACY,
    SECURITY,
    HELP,
    ABOUT
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels {
        val app = application as EquiliApplication
        MainViewModelFactory(
            repository = app.repository,
            aiEngine = app.aiEngine,
            callAssistantManager = app.callAssistantManager,
            voiceManager = app.voiceManager,
            ttsManager = app.ttsManager
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize Android notification channels
        NotificationHelper.initNotificationChannels(this)

        val openTarget = intent?.getStringExtra("OPEN_SCREEN")
        val callerNum = intent?.getStringExtra("CALLER_NUMBER") ?: "+1 (555) 019-2834"
        val callerName = intent?.getStringExtra("CALLER_NAME") ?: "Incoming Caller"
        val autoAnswer = intent?.getBooleanExtra("AUTO_ANSWER", false) ?: false

        if (autoAnswer && openTarget == "LIVE_CALL") {
            viewModel.startLiveAiCall(callerNum, callerName, isSimulated = false)
        }

        setContent {
            val uiState by viewModel.uiState.collectAsState()
            val darkTheme = when (uiState.preferences.appearanceMode) {
                "DARK" -> true
                "LIGHT" -> false
                else -> isSystemInDarkTheme()
            }

            EquiliAITheme(darkTheme = darkTheme) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                        .safeDrawingPadding()
                ) {
                    EquiliMainApp(
                        viewModel = viewModel,
                        initialTarget = openTarget
                    )
                }
            }
        }
    }
}

@Composable
fun EquiliMainApp(
    viewModel: MainViewModel,
    initialTarget: String? = null
) {
    val uiState by viewModel.uiState.collectAsState()
    val prefs = uiState.preferences

    // State for OTP screen
    var pendingOtpPhone by remember { mutableStateOf("") }
    var pendingOtpHint by remember { mutableStateOf("123456") }

    // Initial screen routing based on session
    var currentScreen by remember {
        mutableStateOf(
            when {
                initialTarget == "LIVE_CALL" -> Screen.LIVE_CALL
                initialTarget == "CALL_ASSISTANT" -> Screen.CALL_ASSISTANT
                !prefs.isAuthenticated -> Screen.PHONE_LOGIN
                !prefs.isSetupCompleted -> Screen.PROFILE_SETUP
                else -> Screen.DASHBOARD
            }
        )
    }

    // Keep screen aligned when auth state changes (e.g. logout or delete account)
    LaunchedEffect(prefs.isAuthenticated) {
        if (!prefs.isAuthenticated && currentScreen != Screen.OTP_VERIFICATION) {
            currentScreen = Screen.PHONE_LOGIN
        }
    }

    when (currentScreen) {
        // Step 1: Mobile Number Login
        Screen.PHONE_LOGIN -> {
            PhoneLoginScreen(
                authManager = viewModel.authManager,
                onOtpSent = { formattedNumber, hintCode ->
                    pendingOtpPhone = formattedNumber
                    pendingOtpHint = hintCode
                    currentScreen = Screen.OTP_VERIFICATION
                }
            )
        }

        // Step 2: OTP Verification
        Screen.OTP_VERIFICATION -> {
            BackHandler {
                currentScreen = Screen.PHONE_LOGIN
            }
            OtpVerificationScreen(
                formattedPhone = pendingOtpPhone,
                hintCode = pendingOtpHint,
                authManager = viewModel.authManager,
                onVerified = { userId, phoneNumber ->
                    viewModel.onPhoneVerified(userId, phoneNumber)
                    currentScreen = Screen.PROFILE_SETUP
                },
                onChangeNumber = {
                    currentScreen = Screen.PHONE_LOGIN
                }
            )
        }

        // Step 3: Name & Profile Setup
        Screen.PROFILE_SETUP -> {
            ProfileSetupScreen(
                initialName = prefs.userName,
                initialAvatar = prefs.userAvatar,
                onContinue = { name, avatar ->
                    viewModel.setUserProfile(name, avatar)
                    currentScreen = Screen.LANGUAGE_VOICE_SETUP
                }
            )
        }

        // Step 4: Language & Voice Selection
        Screen.LANGUAGE_VOICE_SETUP -> {
            BackHandler {
                currentScreen = Screen.PROFILE_SETUP
            }
            LanguageVoiceSetupScreen(
                currentLanguage = prefs.assistantLanguage,
                currentVoiceId = prefs.aiVoiceId,
                onPreviewVoice = { voiceId, lang ->
                    viewModel.setAiVoiceId(voiceId)
                    viewModel.speakText("Hello, this is your selected AI voice personality.")
                },
                onContinue = { lang, voiceId ->
                    viewModel.setLanguage(lang)
                    viewModel.setAiVoiceId(voiceId)
                    currentScreen = Screen.PERMISSION_CENTER
                }
            )
        }

        // Step 5: Permission Center
        Screen.PERMISSION_CENTER -> {
            BackHandler {
                if (!prefs.isSetupCompleted) {
                    currentScreen = Screen.LANGUAGE_VOICE_SETUP
                } else {
                    currentScreen = Screen.DASHBOARD
                }
            }
            PermissionsSetupScreen(
                viewModel = viewModel,
                buttonTitle = if (!prefs.isSetupCompleted) "Continue to AI Assistant Setup" else "Done",
                onCompleteSetup = {
                    if (!prefs.isSetupCompleted) {
                        currentScreen = Screen.AI_ASSISTANT_SETUP
                    } else {
                        currentScreen = Screen.DASHBOARD
                    }
                },
                onBackClick = {
                    if (!prefs.isSetupCompleted) {
                        currentScreen = Screen.LANGUAGE_VOICE_SETUP
                    } else {
                        currentScreen = Screen.DASHBOARD
                    }
                }
            )
        }

        // Step 6: AI Assistant Setup
        Screen.AI_ASSISTANT_SETUP -> {
            BackHandler {
                currentScreen = Screen.PERMISSION_CENTER
            }
            AssistantSetupScreen(
                initialAssistantEnabled = prefs.isAssistantEnabled,
                initialAutoSpeak = prefs.autoSpeakEnabled,
                onContinue = { enabled, autoSpeak ->
                    viewModel.toggleAssistant(enabled)
                    viewModel.setAutoSpeak(autoSpeak)
                    currentScreen = Screen.CALL_ASSISTANT_SETUP
                }
            )
        }

        // Step 7: AI Call Assistant Setup
        Screen.CALL_ASSISTANT_SETUP -> {
            BackHandler {
                currentScreen = Screen.AI_ASSISTANT_SETUP
            }
            CallAssistantSetupScreen(
                initialCallEnabled = prefs.isCallAssistantEnabled,
                initialLetAiAnswer = prefs.letAiAnswerCalls,
                initialAskBeforeAnswer = prefs.askMeBeforeAiAnswers,
                initialTransferToMe = prefs.transferCallToMeEnabled,
                initialGreeting = prefs.callGreetingText,
                telecomCapability = uiState.telecomCapability,
                onPreviewGreeting = { text ->
                    viewModel.speakText(text)
                },
                onContinue = { enabled, letAiAnswer, askBeforeAnswer, transferToMe, greeting ->
                    viewModel.toggleCallAssistant(enabled)
                    viewModel.setLetAiAnswerCalls(letAiAnswer)
                    viewModel.setAskMeBeforeAiAnswers(askBeforeAnswer)
                    viewModel.setTransferCallToMeEnabled(transferToMe)
                    viewModel.setCallGreetingText(greeting)
                    currentScreen = Screen.SETUP_COMPLETE
                }
            )
        }

        // Step 8: Setup Complete
        Screen.SETUP_COMPLETE -> {
            SetupCompleteScreen(
                preferences = prefs,
                onEnterDashboard = {
                    viewModel.completeSetup()
                    currentScreen = Screen.DASHBOARD
                }
            )
        }

        // Step 9: Main Dashboard
        Screen.DASHBOARD -> {
            DashboardScreen(
                viewModel = viewModel,
                onNavigateToVoice = { currentScreen = Screen.VOICE_ASSISTANT },
                onNavigateToCall = { currentScreen = Screen.CALL_ASSISTANT },
                onNavigateToCallHistory = { currentScreen = Screen.CALL_HISTORY },
                onNavigateToAccount = { currentScreen = Screen.ACCOUNT },
                onNavigateToPermissions = { currentScreen = Screen.PERMISSION_CENTER },
                onNavigateToPrivacy = { currentScreen = Screen.PRIVACY },
                onNavigateToSettings = { currentScreen = Screen.SETTINGS },
                onNavigateToAbout = { currentScreen = Screen.ABOUT },
                onNavigateToSetup = { currentScreen = Screen.PROFILE_SETUP }
            )
        }

        // Feature: Voice Assistant
        Screen.VOICE_ASSISTANT -> {
            BackHandler {
                viewModel.stopListening()
                viewModel.stopSpeaking()
                currentScreen = Screen.DASHBOARD
            }
            VoiceAssistantScreen(
                viewModel = viewModel,
                onBackClick = {
                    viewModel.stopListening()
                    viewModel.stopSpeaking()
                    currentScreen = Screen.DASHBOARD
                }
            )
        }

        // Feature: Call Assistant Hub & Settings
        Screen.CALL_ASSISTANT -> {
            BackHandler {
                viewModel.stopSpeaking()
                currentScreen = Screen.DASHBOARD
            }
            CallAssistantScreen(
                viewModel = viewModel,
                initialTab = 0,
                onBackClick = {
                    viewModel.stopSpeaking()
                    currentScreen = Screen.DASHBOARD
                },
                onStartLiveCall = { _, _, _ ->
                    currentScreen = Screen.LIVE_CALL
                }
            )
        }

        // Feature: Call History & Summaries
        Screen.CALL_HISTORY -> {
            BackHandler {
                viewModel.stopSpeaking()
                currentScreen = Screen.DASHBOARD
            }
            CallAssistantScreen(
                viewModel = viewModel,
                initialTab = 1,
                onBackClick = {
                    viewModel.stopSpeaking()
                    currentScreen = Screen.DASHBOARD
                },
                onStartLiveCall = { _, _, _ ->
                    currentScreen = Screen.LIVE_CALL
                }
            )
        }

        // Feature: Live Call Screen
        Screen.LIVE_CALL -> {
            BackHandler {
                viewModel.endCallSession()
                currentScreen = Screen.CALL_ASSISTANT
            }
            LiveCallScreen(
                viewModel = viewModel,
                onCallEnded = {
                    currentScreen = Screen.CALL_ASSISTANT
                }
            )
        }

        // Account Details & Sign Out
        Screen.ACCOUNT -> {
            BackHandler {
                currentScreen = Screen.DASHBOARD
            }
            AccountScreen(
                viewModel = viewModel,
                onBackClick = { currentScreen = Screen.DASHBOARD },
                onLogout = {
                    currentScreen = Screen.PHONE_LOGIN
                }
            )
        }

        // Settings Screen
        Screen.SETTINGS -> {
            BackHandler {
                currentScreen = Screen.DASHBOARD
            }
            SettingsScreen(
                viewModel = viewModel,
                onBackClick = { currentScreen = Screen.DASHBOARD },
                onNavigateToAccount = { currentScreen = Screen.ACCOUNT },
                onNavigateToPermissions = { currentScreen = Screen.PERMISSION_CENTER },
                onNavigateToPrivacy = { currentScreen = Screen.PRIVACY },
                onNavigateToSecurity = { currentScreen = Screen.SECURITY },
                onNavigateToHelp = { currentScreen = Screen.HELP },
                onNavigateToAbout = { currentScreen = Screen.ABOUT },
                onRestartSetup = { currentScreen = Screen.PROFILE_SETUP },
                onLogout = { currentScreen = Screen.PHONE_LOGIN }
            )
        }

        // Privacy & Data Governance Screen
        Screen.PRIVACY -> {
            BackHandler {
                currentScreen = Screen.DASHBOARD
            }
            PrivacyScreen(
                viewModel = viewModel,
                onBackClick = { currentScreen = Screen.DASHBOARD },
                onLogout = { currentScreen = Screen.PHONE_LOGIN }
            )
        }

        // Security & Encryption Screen
        Screen.SECURITY -> {
            BackHandler {
                currentScreen = Screen.SETTINGS
            }
            SecurityScreen(
                viewModel = viewModel,
                onBackClick = { currentScreen = Screen.SETTINGS }
            )
        }

        // Help & Support Screen
        Screen.HELP -> {
            BackHandler {
                currentScreen = Screen.SETTINGS
            }
            HelpSupportScreen(
                viewModel = viewModel,
                onBackClick = { currentScreen = Screen.SETTINGS },
                onNavigateToPermissions = { currentScreen = Screen.PERMISSION_CENTER }
            )
        }

        // About & Architecture Screen
        Screen.ABOUT -> {
            BackHandler {
                currentScreen = Screen.DASHBOARD
            }
            AboutScreen(
                onBackClick = { currentScreen = Screen.DASHBOARD }
            )
        }
    }
}
