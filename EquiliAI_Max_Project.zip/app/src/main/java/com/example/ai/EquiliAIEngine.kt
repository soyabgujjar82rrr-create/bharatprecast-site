package com.example.ai

import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

sealed class AIResponseResult {
    data class Success(val text: String, val isCloudModel: Boolean) : AIResponseResult()
    data class Error(val message: String, val fallbackText: String) : AIResponseResult()
}

class EquiliAIEngine {

    private val apiService: GeminiApiService by lazy {
        val moshi = Moshi.Builder()
            .add(KotlinJsonAdapterFactory())
            .build()

        val okHttpClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()

        Retrofit.Builder()
            .baseUrl("https://generativelanguage.googleapis.com/")
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiApiService::class.java)
    }

    fun isCloudConfigured(): Boolean {
        val apiKey = BuildConfig.GEMINI_API_KEY.trim()
        return apiKey.isNotEmpty() &&
                apiKey != "MY_GEMINI_API_KEY" &&
                apiKey != "placeholder" &&
                !apiKey.startsWith("YOUR_")
    }

    suspend fun processQuery(
        prompt: String,
        language: String = "en",
        isCallContext: Boolean = false,
        historyTurns: List<Pair<String, String>> = emptyList()
    ): AIResponseResult = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY.trim()
        val hasValidKey = isCloudConfigured()

        if (hasValidKey) {
            try {
                val systemPrompt = buildSystemPrompt(language, isCallContext)
                val contentsList = mutableListOf<GeminiContent>()

                historyTurns.takeLast(8).forEach { (speaker, text) ->
                    val role = if (speaker.equals("user", ignoreCase = true)) "user" else "model"
                    contentsList.add(
                        GeminiContent(
                            role = role,
                            parts = listOf(GeminiPart(text = text))
                        )
                    )
                }

                contentsList.add(
                    GeminiContent(
                        role = "user",
                        parts = listOf(GeminiPart(text = prompt))
                    )
                )

                val request = GeminiRequest(
                    contents = contentsList,
                    systemInstruction = GeminiContent(
                        parts = listOf(GeminiPart(text = systemPrompt))
                    )
                )

                val response = apiService.generateContent(
                    model = "gemini-2.5-flash",
                    apiKey = apiKey,
                    request = request
                )

                if (response.isSuccessful) {
                    val body = response.body()
                    val candidateText = body?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    if (!candidateText.isNullOrBlank()) {
                        return@withContext AIResponseResult.Success(
                            text = candidateText.trim(),
                            isCloudModel = true
                        )
                    }
                }
            } catch (e: Exception) {
                // Network or API failure -> graceful fallback with honest error reporting
                val fallback = generateLocalResponse(prompt, language, isCallContext)
                return@withContext AIResponseResult.Error(
                    message = "Cloud AI unreachable (${e.localizedMessage ?: "Network error"}). Local fallback activated.",
                    fallbackText = fallback
                )
            }
        }

        // Offline / on-device intelligent engine fallback
        val localText = generateLocalResponse(prompt, language, isCallContext)
        AIResponseResult.Success(
            text = localText,
            isCloudModel = false
        )
    }

    suspend fun processCallDialogue(
        callerUtterance: String,
        language: String,
        historyTurns: List<Pair<String, String>>
    ): AIResponseResult = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY.trim()
        val hasValidKey = apiKey.isNotEmpty() &&
                apiKey != "MY_GEMINI_API_KEY" &&
                apiKey != "placeholder" &&
                !apiKey.startsWith("YOUR_")

        if (hasValidKey) {
            try {
                val systemPrompt = """
                    You are EquiliAI Max, an intelligent AI Call Assistant answering a telephone call on behalf of the user.
                    Current Language: $language.
                    Conversation Guidelines:
                    - Be polite, professional, and natural.
                    - Keep your spoken response concise (1-2 sentences maximum).
                    - If the caller asks for the user, ask if they would like to leave a message or if you should transfer the call to the user.
                    - If the caller explains their purpose, acknowledge and summarize clearly.
                    - Avoid bullet points, symbols, or formatting since this will be spoken aloud via text-to-speech.
                """.trimIndent()

                val contentsList = mutableListOf<GeminiContent>()
                historyTurns.takeLast(6).forEach { (speaker, text) ->
                    val role = if (speaker.equals("caller", ignoreCase = true)) "user" else "model"
                    contentsList.add(GeminiContent(role = role, parts = listOf(GeminiPart(text = text))))
                }
                contentsList.add(GeminiContent(role = "user", parts = listOf(GeminiPart(text = callerUtterance))))

                val request = GeminiRequest(
                    contents = contentsList,
                    systemInstruction = GeminiContent(parts = listOf(GeminiPart(text = systemPrompt)))
                )

                val response = apiService.generateContent(
                    model = "gemini-2.5-flash",
                    apiKey = apiKey,
                    request = request
                )

                if (response.isSuccessful) {
                    val candidateText = response.body()?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    if (!candidateText.isNullOrBlank()) {
                        return@withContext AIResponseResult.Success(
                            text = candidateText.trim().replace("*", ""),
                            isCloudModel = true
                        )
                    }
                }
            } catch (e: Exception) {
                val fallback = generateCallLocalResponse(callerUtterance, language)
                return@withContext AIResponseResult.Error(
                    message = "Cloud AI unreachable: ${e.localizedMessage}",
                    fallbackText = fallback
                )
            }
        }

        val local = generateCallLocalResponse(callerUtterance, language)
        AIResponseResult.Success(text = local, isCloudModel = false)
    }

    suspend fun generateCallSummary(transcript: String, language: String): String = withContext(Dispatchers.IO) {
        if (transcript.isBlank()) return@withContext "Brief call with no spoken content."

        val apiKey = BuildConfig.GEMINI_API_KEY.trim()
        val hasValidKey = apiKey.isNotEmpty() && apiKey != "MY_GEMINI_API_KEY" && !apiKey.startsWith("YOUR_")

        if (hasValidKey) {
            try {
                val request = GeminiRequest(
                    contents = listOf(
                        GeminiContent(
                            role = "user",
                            parts = listOf(GeminiPart(text = "Summarize the caller's main intent and message from this phone call transcript in 1 single sentence:\n\n$transcript"))
                        )
                    )
                )
                val response = apiService.generateContent(
                    model = "gemini-2.5-flash",
                    apiKey = apiKey,
                    request = request
                )
                val summary = response.body()?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (!summary.isNullOrBlank()) {
                    return@withContext summary.trim().replace("*", "")
                }
            } catch (_: Exception) {}
        }

        // Local heuristic summary fallback
        return@withContext if (language.equals("hi", ignoreCase = true)) {
            "कॉल में कॉलर ने संदेश छोड़ा या संपर्क करने का अनुरोध किया।"
        } else {
            "Caller contacted for information or left a message for callback."
        }
    }

    private fun buildSystemPrompt(language: String, isCallContext: Boolean): String {
        val langInstruction = when (language.lowercase()) {
            "hi" -> "Respond natively in Hindi (Devanagari script), natural and polite."
            "hinglish" -> "Respond in natural Hinglish (conversational Hindi using English alphabet)."
            else -> "Respond in clear, natural, and concise English."
        }
        return if (isCallContext) {
            """
            You are the EquiliAI Max Call Assistant. You provide smart, polite call screening suggestions and concise auto-replies.
            $langInstruction
            Keep responses to 1-2 short sentences suitable for quick spoken or SMS delivery.
            """.trimIndent()
        } else {
            """
            You are EquiliAI Max, an advanced voice assistant. 
            $langInstruction
            Keep spoken voice answers natural, helpful, and concise (under 3 sentences unless asked for details).
            Do not use markdown formatting like asterisks or bullet points in voice answers.
            """.trimIndent()
        }
    }

    fun generateCallLocalResponse(callerUtterance: String, language: String): String {
        val lower = callerUtterance.lowercase().trim()
        val isHindi = language.lowercase() == "hi"

        return when {
            lower.contains("hello") || lower.contains("hi") || lower.contains("नमस्ते") -> {
                if (isHindi) "नमस्ते, मैं EquiliAI कॉल सहायक हूँ। क्या आप कोई संदेश छोड़ना चाहेंगे या कॉल ट्रांसफर करूँ?"
                else "Hello, I am the EquiliAI Call Assistant. Would you like to leave a message, or shall I transfer you?"
            }
            lower.contains("who is this") || lower.contains("who are you") || lower.contains("कौन बोल रहा है") -> {
                if (isHindi) "मैं EquiliAI Max हूँ, एक बुद्धिमान कॉल सहायक जो कॉल स्क्रीन कर रहा है।"
                else "This is EquiliAI Max, an automated AI Call Assistant screening this line on behalf of the user."
            }
            lower.contains("urgent") || lower.contains("emergency") || lower.contains("जरूरी") || lower.contains("अर्जेंट") -> {
                if (isHindi) "समझ गया, यह अत्यावश्यक है। मैं तुरंत उपयोगकर्ता को कॉल ट्रांसफर करने का प्रयास कर रहा हूँ।"
                else "Understood, since this is urgent, I am alerting the user to take over the call immediately."
            }
            lower.contains("appointment") || lower.contains("schedule") || lower.contains("meeting") || lower.contains("मीटिंग") -> {
                if (isHindi) "मैंने आपकी मीटिंग संबंधी जानकारी नोट कर ली है। उपयोगकर्ता जल्द ही आपसे संपर्क करेंगे।"
                else "I have noted your meeting request. The user has been notified and will get back to you shortly."
            }
            lower.contains("transfer") || lower.contains("talk to") || lower.contains("speak with") || lower.contains("बात करनी है") -> {
                if (isHindi) "कृपया एक पल प्रतीक्षा करें, मैं कॉल उपयोगकर्ता को ट्रांसफर कर रहा हूँ।"
                else "Please hold on for a moment while I transfer this call to the user."
            }
            else -> {
                if (isHindi) {
                    "धन्यवाद, मैंने आपका संदेश प्राप्त कर लिया है: \"$callerUtterance\"। मैं उपयोगकर्ता को सूचित कर दूंगा।"
                } else {
                    "Thank you, I have recorded your message: \"$callerUtterance\". The recipient will receive this summary."
                }
            }
        }
    }

    fun generateLocalResponse(prompt: String, language: String, isCallContext: Boolean): String {
        val lower = prompt.lowercase().trim()
        val isHindi = language.lowercase() == "hi"

        if (isCallContext) {
            return generateCallLocalResponse(prompt, language)
        }

        return when {
            lower.contains("hello") || lower.contains("hi") || lower.contains("hey") || lower.contains("नमस्ते") -> {
                if (isHindi) "नमस्ते! मैं EquiliAI Max हूँ। मैं आपकी क्या मदद कर सकता हूँ?"
                else "Hello! I am EquiliAI Max, your intelligent voice and call assistant. How can I help you today?"
            }
            lower.contains("who are you") || lower.contains("about") || lower.contains("तुम कौन हो") || lower.contains("कौन हो") -> {
                if (isHindi) "मैं EquiliAI Max हूँ — एक आधुनिक, सुरक्षित वॉइस और कॉल सहायक।"
                else "I am EquiliAI Max, an on-device AI voice and call assistant built with privacy-first architecture."
            }
            lower.contains("call") || lower.contains("screening") || lower.contains("कॉल") -> {
                if (isHindi) "EquiliAI कॉल सहायक इनकमिंग कॉल का पता लगाकर स्मार्ट अलर्ट और सुझाव प्रदान करता है।"
                else "EquiliAI Call Assistant detects incoming calls and provides real-time screening prompts and smart reply options."
            }
            lower.contains("time") || lower.contains("समय") || lower.contains("time now") -> {
                val now = java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault()).format(java.util.Date())
                if (isHindi) "वर्तमान समय $now है।"
                else "The current time is $now."
            }
            lower.contains("date") || lower.contains("तारीख") || lower.contains("दिनांक") -> {
                val today = java.text.SimpleDateFormat("EEEE, MMMM d, yyyy", java.util.Locale.getDefault()).format(java.util.Date())
                if (isHindi) "आज की तारीख $today है।"
                else "Today is $today."
            }
            lower.contains("help") || lower.contains("मदद") || lower.contains("सहायता") -> {
                if (isHindi) "आप मुझसे समय पूछ सकते हैं, कॉल सहायक के बारे में जान सकते हैं, या कोई भी सवाल पूछ सकते हैं।"
                else "You can ask me questions, test voice commands, explore call screening modes, or configure privacy settings."
            }
            lower.contains("weather") || lower.contains("मौसम") -> {
                if (isHindi) "मौसम सामान्य और साफ़ लग रहा है। विस्तृत जानकारी के लिए नेटवर्क सक्रिय करें।"
                else "Current conditions appear clear. Connect to network for live meteorological telemetry."
            }
            else -> {
                if (isHindi) {
                    "EquiliAI Max ने आपका संदेश प्राप्त किया: \"$prompt\"। संपूर्ण क्लाउड न्यूरल मॉडल के लिए सेटिंग्स में API कुंजी जांचें।"
                } else {
                    "I received your request: \"$prompt\". EquiliAI local intelligence is running smoothly. Connect an API key in settings for expanded Gemini knowledge."
                }
            }
        }
    }
}
