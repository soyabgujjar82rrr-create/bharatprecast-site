package com.example.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class TextToSpeechManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private var currentUtteranceCallback: (() -> Unit)? = null

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                    val cb = currentUtteranceCallback
                    currentUtteranceCallback = null
                    cb?.invoke()
                }

                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                    val cb = currentUtteranceCallback
                    currentUtteranceCallback = null
                    cb?.invoke()
                }
            })
        } else {
            isInitialized = false
        }
    }

    fun speak(
        text: String,
        languageCode: String = "en",
        speechRate: Float = 1.0f,
        pitch: Float = 1.0f,
        onComplete: (() -> Unit)? = null
    ) {
        if (!isInitialized || tts == null) {
            onComplete?.invoke()
            return
        }

        currentUtteranceCallback = onComplete

        val locale = when (languageCode.lowercase()) {
            "hi" -> Locale("hi", "IN")
            else -> Locale.US
        }

        try {
            tts?.language = locale
            tts?.setSpeechRate(speechRate.coerceIn(0.5f, 2.0f))
            tts?.setPitch(pitch.coerceIn(0.5f, 2.0f))
            val utteranceId = "EquiliUtterance_${System.currentTimeMillis()}"
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        } catch (_: Exception) {
            onComplete?.invoke()
        }
    }

    fun stop() {
        try {
            currentUtteranceCallback = null
            tts?.stop()
        } catch (_: Exception) {}
        _isSpeaking.value = false
    }

    fun shutdown() {
        try {
            currentUtteranceCallback = null
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {}
        tts = null
        isInitialized = false
    }
}
