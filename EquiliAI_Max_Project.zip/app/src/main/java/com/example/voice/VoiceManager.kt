package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

sealed class VoiceState {
    object Idle : VoiceState()
    object Ready : VoiceState()
    data class Listening(val rmsDb: Float) : VoiceState()
    object Processing : VoiceState()
    data class Recognized(val text: String) : VoiceState()
    data class Error(val message: String, val canRetry: Boolean) : VoiceState()
}

class VoiceManager(private val context: Context) {

    private var speechRecognizer: SpeechRecognizer? = null
    private val _voiceState = MutableStateFlow<VoiceState>(VoiceState.Idle)
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    private val isAvailable: Boolean
        get() = SpeechRecognizer.isRecognitionAvailable(context)

    fun startListening(languageCode: String = "en-US") {
        if (!isAvailable) {
            _voiceState.value = VoiceState.Error(
                message = "Speech recognition service is not available on this device. You can type your request directly.",
                canRetry = false
            )
            return
        }

        stopListening()

        try {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _voiceState.value = VoiceState.Ready
                    }

                    override fun onBeginningOfSpeech() {
                        _voiceState.value = VoiceState.Listening(0f)
                    }

                    override fun onRmsChanged(rmsdB: Float) {
                        if (_voiceState.value is VoiceState.Listening || _voiceState.value is VoiceState.Ready) {
                            _voiceState.value = VoiceState.Listening(rmsdB)
                        }
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        _voiceState.value = VoiceState.Processing
                    }

                    override fun onError(error: Int) {
                        val message = when (error) {
                            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error. Check microphone."
                            SpeechRecognizer.ERROR_CLIENT -> "Client-side recognition error."
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required."
                            SpeechRecognizer.ERROR_NETWORK -> "Network connection error for speech engine."
                            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timed out. Please retry."
                            SpeechRecognizer.ERROR_NO_MATCH -> "No speech detected. Please speak closer to microphone."
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognizer is busy. Try again in a moment."
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech heard. Tap to try again."
                            else -> "Speech recognition encountered an issue (Code: $error)."
                        }
                        _voiceState.value = VoiceState.Error(message = message, canRetry = true)
                    }

                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull() ?: ""
                        if (text.isNotBlank()) {
                            _voiceState.value = VoiceState.Recognized(text)
                        } else {
                            _voiceState.value = VoiceState.Error("No words detected.", canRetry = true)
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        matches?.firstOrNull()?.let {
                            if (it.isNotBlank()) {
                                _voiceState.value = VoiceState.Listening(10f)
                            }
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageCode)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }

            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            _voiceState.value = VoiceState.Error("Could not start microphone: ${e.message}", canRetry = true)
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.destroy()
        } catch (_: Exception) {}
        speechRecognizer = null
        if (_voiceState.value is VoiceState.Listening || _voiceState.value is VoiceState.Ready) {
            _voiceState.value = VoiceState.Idle
        }
    }

    fun resetState() {
        stopListening()
        _voiceState.value = VoiceState.Idle
    }
}
