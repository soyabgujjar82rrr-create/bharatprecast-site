package com.example.permissions

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat

enum class PermissionStateStatus {
    GRANTED,
    NOT_GRANTED,
    NOT_SUPPORTED
}

enum class PermissionType(
    val title: String,
    val permissionManifest: String,
    val description: String,
    val legalNote: String,
    val isMandatoryForVoice: Boolean
) {
    MICROPHONE(
        title = "Microphone Access",
        permissionManifest = Manifest.permission.RECORD_AUDIO,
        description = "Required for speech-to-text recognition, hands-free voice commands, and speech analysis.",
        legalNote = "Audio is processed dynamically in memory and never transmitted without active query invocation.",
        isMandatoryForVoice = true
    ),
    NOTIFICATIONS(
        title = "Notifications",
        permissionManifest = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.POST_NOTIFICATIONS
        } else {
            ""
        },
        description = "Required to deliver incoming call alerts, screening notifications, and voice assistant status.",
        legalNote = "Standard system notification channel with complete user silence controls.",
        isMandatoryForVoice = false
    ),
    PHONE_STATE(
        title = "Phone State Access",
        permissionManifest = Manifest.permission.READ_PHONE_STATE,
        description = "Required to detect incoming calls (ringing, idle, off-hook) for real-time screening prompts.",
        legalNote = "Android Security Policy: Allows call status detection only. Ordinary apps cannot hijack or record audio without telecom roles.",
        isMandatoryForVoice = false
    ),
    CONTACTS(
        title = "Contacts (Caller ID)",
        permissionManifest = Manifest.permission.READ_CONTACTS,
        description = "Optional permission used to display caller names instead of unknown numbers during call screening.",
        legalNote = "Contacts are read strictly locally on-device and are never uploaded or synced to external servers.",
        isMandatoryForVoice = false
    )
}

data class PermissionStatusItem(
    val type: PermissionType,
    val state: PermissionStateStatus,
    val rationale: String
) {
    val isGranted: Boolean
        get() = state == PermissionStateStatus.GRANTED
}

object PermissionHelper {

    fun checkPermissionState(context: Context, type: PermissionType): PermissionStateStatus {
        if (type == PermissionType.NOTIFICATIONS && Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            // Notifications do not require runtime permission prior to Android 13
            return PermissionStateStatus.GRANTED
        }

        if (type.permissionManifest.isEmpty()) {
            return PermissionStateStatus.GRANTED
        }

        val isGranted = ContextCompat.checkSelfPermission(
            context,
            type.permissionManifest
        ) == PackageManager.PERMISSION_GRANTED

        return if (isGranted) PermissionStateStatus.GRANTED else PermissionStateStatus.NOT_GRANTED
    }

    fun isPermissionGranted(context: Context, permissionManifest: String): Boolean {
        if (permissionManifest.isEmpty()) return true
        return ContextCompat.checkSelfPermission(
            context,
            permissionManifest
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun getPermissionStatuses(context: Context): List<PermissionStatusItem> {
        return PermissionType.values().map { type ->
            val status = checkPermissionState(context, type)
            val rationale = when (status) {
                PermissionStateStatus.GRANTED -> "Granted & Operational"
                PermissionStateStatus.NOT_GRANTED -> "Not Granted (Tap to Configure)"
                PermissionStateStatus.NOT_SUPPORTED -> "Not Supported on this Android version"
            }
            PermissionStatusItem(
                type = type,
                state = status,
                rationale = rationale
            )
        }
    }

    fun openAppSettings(context: Context) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", context.packageName, null)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }
}
