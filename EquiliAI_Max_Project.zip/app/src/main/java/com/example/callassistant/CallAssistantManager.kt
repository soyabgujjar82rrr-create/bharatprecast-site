package com.example.callassistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telecom.TelecomManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.ai.AIResponseResult
import com.example.ai.EquiliAIEngine
import com.example.data.repository.EquiliRepository
import com.example.permissions.PermissionHelper
import com.example.voice.TextToSpeechManager
import com.example.voice.VoiceManager
import com.example.voice.VoiceState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class LiveCallSessionState(
    val isActive: Boolean = false,
    val callerNumber: String = "",
    val callerName: String = "",
    val status: CallSessionStatus = CallSessionStatus.ENDED,
    val durationSeconds: Int = 0,
    val transcripts: List<CallTranscriptTurn> = emptyList(),
    val isMuted: Boolean = false,
    val isSpeakerOn: Boolean = true,
    val isTransferredToUser: Boolean = false,
    val isSimulated: Boolean = false,
    val networkState: String = "Cloud AI Connected"
)

class CallAssistantManager(
    private val context: Context,
    private val repository: EquiliRepository
) {
    companion object {
        const val CHANNEL_ID = "equili_call_assistant_channel"
        const val NOTIFICATION_ID = 2001
        const val CALL_ALERT_NOTIFICATION_ID = 2002
    }

    private val scope = CoroutineScope(Dispatchers.Main)

    private val _sessionState = MutableStateFlow(LiveCallSessionState())
    val sessionState: StateFlow<LiveCallSessionState> = _sessionState.asStateFlow()

    private var durationJob: Job? = null
    private var aiEngineRef: EquiliAIEngine? = null
    private var voiceManagerRef: VoiceManager? = null
    private var ttsManagerRef: TextToSpeechManager? = null

    init {
        createNotificationChannel()
    }

    fun attachEngines(
        aiEngine: EquiliAIEngine,
        voiceManager: VoiceManager,
        ttsManager: TextToSpeechManager
    ) {
        aiEngineRef = aiEngine
        voiceManagerRef = voiceManager
        ttsManagerRef = ttsManager

        // Collect voice recognition during active call sessions
        scope.launch {
            voiceManager.voiceState.collect { state ->
                val current = _sessionState.value
                if (current.isActive && current.status == CallSessionStatus.LISTENING_CALLER) {
                    if (state is VoiceState.Recognized && state.text.isNotBlank()) {
                        handleCallerSpokenUtterance(state.text)
                    }
                }
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Call Assistant Screening"
            val descriptionText = "Notifications for incoming call screening and AI prompts"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                enableVibration(true)
            }
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun getTelecomCapability(context: Context): TelecomCapabilityInfo {
        val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
        val isDefaultDialer = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            telecomManager?.defaultDialerPackage == context.packageName
        } else {
            false
        }

        val hasScreeningRole = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = context.getSystemService(Context.ROLE_SERVICE) as? RoleManager
            roleManager?.isRoleHeld(RoleManager.ROLE_CALL_SCREENING) ?: false
        } else {
            false
        }

        val micGranted = PermissionHelper.isPermissionGranted(context, android.Manifest.permission.RECORD_AUDIO)
        val phoneGranted = PermissionHelper.isPermissionGranted(context, android.Manifest.permission.READ_PHONE_STATE)

        val summary = when {
            isDefaultDialer -> "EquiliAI is configured as system Default Phone App. Full automatic call management supported."
            hasScreeningRole -> "EquiliAI holds Call Screening Role. Incoming call identification and spam filtering active."
            else -> "Operating in Companion Assistant Mode. Incoming calls trigger heads-up screening alerts and AI assistance."
        }

        val limitation = "Android Security Policy: Standard third-party apps cannot silently answer calls or intercept carrier voice channels without the system Telecom CallScreeningService or Default Dialing role. EquiliAI Max provides official call screening alerts and conversational handoff."

        return TelecomCapabilityInfo(
            hasCallScreeningRole = hasScreeningRole,
            isDefaultDialer = isDefaultDialer,
            isReadPhoneStateGranted = phoneGranted,
            isMicrophoneGranted = micGranted,
            supportedSummary = summary,
            limitationNotice = limitation
        )
    }

    fun handleIncomingCallDetected(phoneNumber: String, state: String, isSimulated: Boolean = false) {
        scope.launch(Dispatchers.IO) {
            val prefs = repository.getPreferencesDirect()
            if (!prefs.isCallAssistantEnabled) return@launch

            val callerLabel = if (phoneNumber.isBlank() || phoneNumber == "Unknown") "+1 (555) 019-2834" else phoneNumber
            val callerName = if (isSimulated) "Simulated Incoming Caller" else "Incoming Caller"

            if (prefs.letAiAnswerCalls && !prefs.askMeBeforeAiAnswers) {
                // User chose auto-answer without prompting
                startAiCallHandling(callerLabel, callerName, isSimulated)
            } else {
                // Post heads-up notification for user to answer with AI or dismiss
                _sessionState.value = LiveCallSessionState(
                    isActive = false,
                    callerNumber = callerLabel,
                    callerName = callerName,
                    status = CallSessionStatus.INCOMING_ALERT,
                    isSimulated = isSimulated
                )
                showScreeningNotification(callerLabel, callerName, isSimulated)
            }
        }
    }

    fun startAiCallHandling(
        callerNumber: String,
        callerName: String,
        isSimulated: Boolean = false
    ) {
        durationJob?.cancel()
        dismissNotifications()

        _sessionState.value = LiveCallSessionState(
            isActive = true,
            callerNumber = callerNumber,
            callerName = callerName,
            status = CallSessionStatus.GREETING,
            durationSeconds = 0,
            transcripts = emptyList(),
            isSimulated = isSimulated,
            isTransferredToUser = false
        )

        // Start call duration counter
        durationJob = scope.launch {
            while (isActive && _sessionState.value.isActive) {
                delay(1000)
                _sessionState.value = _sessionState.value.copy(
                    durationSeconds = _sessionState.value.durationSeconds + 1
                )
            }
        }

        // Execute Greeting turn
        scope.launch(Dispatchers.IO) {
            val prefs = repository.getPreferencesDirect()
            val greeting = prefs.callGreetingText.ifBlank {
                if (prefs.assistantLanguage == "hi") {
                    "नमस्ते, यह EquiliAI Max कॉल सहायक है। मैं आपकी क्या मदद कर सकता हूँ?"
                } else {
                    "Hello, this is EquiliAI Max. How may I help you?"
                }
            }

            val voiceProfile = AiVoiceProfiles.getById(prefs.aiVoiceId)

            // Record greeting in transcript
            val initialTranscripts = listOf(
                CallTranscriptTurn(speaker = "assistant", text = greeting)
            )

            _sessionState.value = _sessionState.value.copy(
                status = CallSessionStatus.SPEAKING_AI,
                transcripts = initialTranscripts
            )

            // Speak greeting
            ttsManagerRef?.speak(
                text = greeting,
                languageCode = prefs.assistantLanguage,
                speechRate = voiceProfile.speed,
                pitch = voiceProfile.pitch,
                onComplete = {
                    // When AI finishes greeting, start listening to caller
                    _sessionState.value = _sessionState.value.copy(
                        status = CallSessionStatus.LISTENING_CALLER
                    )
                    startListeningToCaller(prefs.assistantLanguage)
                }
            )
        }
    }

    private fun startListeningToCaller(language: String) {
        val langCode = if (language == "hi") "hi-IN" else "en-US"
        voiceManagerRef?.startListening(langCode)
    }

    fun handleCallerSpokenUtterance(utterance: String) {
        if (utterance.isBlank()) return
        val current = _sessionState.value
        if (!current.isActive || current.isTransferredToUser) return

        voiceManagerRef?.stopListening()

        val updatedTranscripts = current.transcripts + CallTranscriptTurn(
            speaker = "caller",
            text = utterance
        )

        _sessionState.value = current.copy(
            status = CallSessionStatus.PROCESSING_AI,
            transcripts = updatedTranscripts
        )

        scope.launch(Dispatchers.IO) {
            val prefs = repository.getPreferencesDirect()
            val voiceProfile = AiVoiceProfiles.getById(prefs.aiVoiceId)

            val history = updatedTranscripts.map { it.speaker to it.text }

            val aiResult = aiEngineRef?.processCallDialogue(
                callerUtterance = utterance,
                language = prefs.assistantLanguage,
                historyTurns = history
            )

            val replyText = when (aiResult) {
                is AIResponseResult.Success -> aiResult.text
                is AIResponseResult.Error -> aiResult.fallbackText
                null -> "I have recorded your message and notified the recipient."
            }

            val finalTranscripts = _sessionState.value.transcripts + CallTranscriptTurn(
                speaker = "assistant",
                text = replyText
            )

            _sessionState.value = _sessionState.value.copy(
                status = CallSessionStatus.SPEAKING_AI,
                transcripts = finalTranscripts
            )

            ttsManagerRef?.speak(
                text = replyText,
                languageCode = prefs.assistantLanguage,
                speechRate = voiceProfile.speed,
                pitch = voiceProfile.pitch,
                onComplete = {
                    if (_sessionState.value.isActive && !_sessionState.value.isTransferredToUser) {
                        _sessionState.value = _sessionState.value.copy(
                            status = CallSessionStatus.LISTENING_CALLER
                        )
                        startListeningToCaller(prefs.assistantLanguage)
                    }
                }
            )
        }
    }

    fun transferCallToUser() {
        ttsManagerRef?.stop()
        voiceManagerRef?.stopListening()

        val current = _sessionState.value
        val handoffNote = CallTranscriptTurn(
            speaker = "system",
            text = "AI conversation stopped. Call control transferred to user (Talk to Me active)."
        )

        _sessionState.value = current.copy(
            status = CallSessionStatus.TRANSFERRED_TO_ME,
            isTransferredToUser = true,
            transcripts = current.transcripts + handoffNote
        )
    }

    fun endCallSession() {
        durationJob?.cancel()
        ttsManagerRef?.stop()
        voiceManagerRef?.stopListening()

        val current = _sessionState.value
        if (!current.isActive && current.status != CallSessionStatus.INCOMING_ALERT) {
            return
        }

        val duration = current.durationSeconds
        val callerNum = current.callerNumber.ifBlank { "Unknown Caller" }
        val callerLabel = current.callerName.ifBlank { "Caller" }

        val transcriptText = current.transcripts.joinToString("\n") {
            "${it.speaker.uppercase()}: ${it.text}"
        }

        val handlingStatus = if (current.isTransferredToUser) {
            "TRANSFERRED_TO_HUMAN"
        } else if (current.transcripts.isNotEmpty()) {
            "AI_ANSWERED"
        } else {
            "SCREENED"
        }

        val action = if (current.isTransferredToUser) {
            "Transferred to User"
        } else if (current.transcripts.isNotEmpty()) {
            "AI Answered & Handled"
        } else {
            "Call Screened / Ended"
        }

        scope.launch(Dispatchers.IO) {
            val prefs = repository.getPreferencesDirect()
            val summary = if (prefs.generateAiSummaries && transcriptText.isNotBlank()) {
                aiEngineRef?.generateCallSummary(transcriptText, prefs.assistantLanguage)
                    ?: "Call completed with AI assistant."
            } else {
                "Call ended after ${duration}s."
            }

            repository.logCallEvent(
                phoneNumber = callerNum,
                callerName = callerLabel,
                state = "COMPLETED",
                actionTaken = action,
                durationSeconds = duration,
                handlingStatus = handlingStatus,
                transcript = transcriptText,
                summary = summary
            )
        }

        _sessionState.value = LiveCallSessionState(
            isActive = false,
            status = CallSessionStatus.ENDED
        )
    }

    fun toggleMute() {
        val current = _sessionState.value
        val newMute = !current.isMuted
        _sessionState.value = current.copy(isMuted = newMute)
        if (newMute) {
            ttsManagerRef?.stop()
            voiceManagerRef?.stopListening()
        }
    }

    fun toggleSpeaker() {
        val current = _sessionState.value
        _sessionState.value = current.copy(isSpeakerOn = !current.isSpeakerOn)
    }

    private fun showScreeningNotification(callerNumber: String, callerName: String, isSimulated: Boolean) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            ?: return

        val answerIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("OPEN_SCREEN", "LIVE_CALL")
            putExtra("CALLER_NUMBER", callerNumber)
            putExtra("CALLER_NAME", callerName)
            putExtra("AUTO_ANSWER", true)
        }

        val answerPendingIntent = PendingIntent.getActivity(
            context,
            101,
            answerIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val prefix = if (isSimulated) "[TEST] " else ""
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("${prefix}EquiliAI Call Assistant: $callerNumber")
            .setContentText("Incoming call detected. Tap to answer with AI or screen.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(answerPendingIntent)
            .setAutoCancel(true)
            .addAction(R.mipmap.ic_launcher, "Answer with AI", answerPendingIntent)
            .build()

        try {
            notificationManager.notify(CALL_ALERT_NOTIFICATION_ID, notification)
        } catch (_: SecurityException) {}
    }

    private fun dismissNotifications() {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        notificationManager?.cancel(CALL_ALERT_NOTIFICATION_ID)
    }
}
