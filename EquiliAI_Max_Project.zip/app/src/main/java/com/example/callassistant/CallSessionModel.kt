package com.example.callassistant

enum class CallSessionStatus {
    INCOMING_ALERT,
    GREETING,
    LISTENING_CALLER,
    PROCESSING_AI,
    SPEAKING_AI,
    TRANSFERRED_TO_ME,
    ENDED
}

data class CallTranscriptTurn(
    val speaker: String, // "caller", "assistant", "system"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class AiVoiceProfile(
    val id: String,
    val name: String,
    val description: String,
    val pitch: Float,
    val speed: Float,
    val languageCode: String
)

object AiVoiceProfiles {
    val ALL = listOf(
        AiVoiceProfile(
            id = "aura",
            name = "Aura (Gentle Female)",
            description = "Warm, polite, conversational tone suited for screening calls.",
            pitch = 1.15f,
            speed = 1.0f,
            languageCode = "en"
        ),
        AiVoiceProfile(
            id = "zephyr",
            name = "Zephyr (Confident Male)",
            description = "Professional and assertive, ideal for screening unknown callers.",
            pitch = 0.85f,
            speed = 1.0f,
            languageCode = "en"
        ),
        AiVoiceProfile(
            id = "nova",
            name = "Nova (Balanced Neutral)",
            description = "Crisp, concise, and ultra-clear speech synthesis.",
            pitch = 1.0f,
            speed = 1.05f,
            languageCode = "en"
        ),
        AiVoiceProfile(
            id = "kavya",
            name = "Kavya (हिन्दी Expressive)",
            description = "Natural Hindi articulation optimized for Devanagari & Hinglish.",
            pitch = 1.1f,
            speed = 0.95f,
            languageCode = "hi"
        )
    )

    fun getById(id: String): AiVoiceProfile {
        return ALL.find { it.id.equals(id, ignoreCase = true) } ?: ALL.first()
    }
}

data class TelecomCapabilityInfo(
    val hasCallScreeningRole: Boolean,
    val isDefaultDialer: Boolean,
    val isReadPhoneStateGranted: Boolean,
    val isMicrophoneGranted: Boolean,
    val supportedSummary: String,
    val limitationNotice: String
)
