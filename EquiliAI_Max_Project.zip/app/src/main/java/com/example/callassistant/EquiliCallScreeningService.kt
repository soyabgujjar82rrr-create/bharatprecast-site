package com.example.callassistant

import android.os.Build
import android.telecom.Call
import android.telecom.CallScreeningService
import androidx.annotation.RequiresApi
import com.example.EquiliApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@RequiresApi(Build.VERSION_CODES.Q)
class EquiliCallScreeningService : CallScreeningService() {

    override fun onScreenCall(callDetails: Call.Details) {
        val app = applicationContext as? EquiliApplication
        val phoneNumber = callDetails.handle?.schemeSpecificPart ?: "Unknown"

        if (app != null) {
            CoroutineScope(Dispatchers.IO).launch {
                val prefs = app.repository.getPreferencesDirect()

                val responseBuilder = CallResponse.Builder()

                // Check spam filtering mode
                val isSpamMode = prefs.callScreeningMode == "SPAM"
                if (isSpamMode && (phoneNumber.startsWith("+1800") || phoneNumber.startsWith("+1888"))) {
                    // Disallow call in spam screening mode
                    responseBuilder.setDisallowCall(true)
                    responseBuilder.setRejectCall(true)
                    responseBuilder.setSkipCallLog(false)
                    responseBuilder.setSkipNotification(false)

                    app.repository.logCallEvent(
                        phoneNumber = phoneNumber,
                        callerName = "Identified Telemarketer/Spam",
                        state = "SCREENED",
                        actionTaken = "Spam Blocked",
                        durationSeconds = 0,
                        handlingStatus = "SCREENED",
                        transcript = "Blocked via EquiliAI Telecom CallScreeningService.",
                        summary = "Potential spam call filtered out."
                    )
                } else {
                    // Allow call to ring and trigger EquiliAI screening notification / assistant
                    responseBuilder.setDisallowCall(false)
                    responseBuilder.setRejectCall(false)

                    app.callAssistantManager.handleIncomingCallDetected(
                        phoneNumber = phoneNumber,
                        state = "RINGING",
                        isSimulated = false
                    )
                }

                respondToCall(callDetails, responseBuilder.build())
            }
        } else {
            respondToCall(callDetails, CallResponse.Builder().setDisallowCall(false).build())
        }
    }
}
