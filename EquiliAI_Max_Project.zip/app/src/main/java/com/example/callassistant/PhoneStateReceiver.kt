package com.example.callassistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import com.example.EquiliApplication

class PhoneStateReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return

        val stateStr = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        val incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: "Unknown"

        val app = context.applicationContext as? EquiliApplication ?: return

        when (stateStr) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                app.callAssistantManager.handleIncomingCallDetected(
                    phoneNumber = incomingNumber,
                    state = "RINGING",
                    isSimulated = false
                )
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                app.callAssistantManager.handleIncomingCallDetected(
                    phoneNumber = incomingNumber,
                    state = "OFFHOOK",
                    isSimulated = false
                )
            }
            TelephonyManager.EXTRA_STATE_IDLE -> {
                // Call ended or missed
            }
        }
    }
}
