package com.example

import android.app.Application
import com.example.ai.EquiliAIEngine
import com.example.callassistant.CallAssistantManager
import com.example.data.AppDatabase
import com.example.data.repository.EquiliRepository
import com.example.voice.TextToSpeechManager
import com.example.voice.VoiceManager

class EquiliApplication : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var repository: EquiliRepository
        private set

    lateinit var aiEngine: EquiliAIEngine
        private set

    lateinit var callAssistantManager: CallAssistantManager
        private set

    lateinit var voiceManager: VoiceManager
        private set

    lateinit var ttsManager: TextToSpeechManager
        private set

    override fun onCreate() {
        super.onCreate()

        database = AppDatabase.getInstance(this)
        repository = EquiliRepository(
            preferencesDao = database.userPreferencesDao(),
            chatMessageDao = database.chatMessageDao(),
            callEventDao = database.callEventDao()
        )
        aiEngine = EquiliAIEngine()
        callAssistantManager = CallAssistantManager(this, repository)
        voiceManager = VoiceManager(this)
        ttsManager = TextToSpeechManager(this)
        callAssistantManager.attachEngines(aiEngine, voiceManager, ttsManager)
    }

    override fun onTerminate() {
        super.onTerminate()
        ttsManager.shutdown()
        voiceManager.stopListening()
    }
}
