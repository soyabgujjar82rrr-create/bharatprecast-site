package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.entity.CallEventEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CallEventDao {
    @Query("SELECT * FROM call_events ORDER BY timestamp DESC LIMIT 100")
    fun getRecentCallEvents(): Flow<List<CallEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCallEvent(event: CallEventEntity): Long

    @Query("UPDATE call_events SET summary = '', reasonForCalling = '', importantInformation = '', actionRequested = '' WHERE id = :id")
    suspend fun clearCallSummary(id: Long)

    @Query("UPDATE call_events SET transcript = '' WHERE id = :id")
    suspend fun clearCallTranscript(id: Long)

    @Query("DELETE FROM call_events WHERE id = :id")
    suspend fun deleteCallEventById(id: Long)

    @Query("UPDATE call_events SET summary = '', reasonForCalling = '', importantInformation = '', actionRequested = ''")
    suspend fun clearAllCallSummaries()

    @Query("UPDATE call_events SET transcript = ''")
    suspend fun clearAllCallTranscripts()

    @Query("DELETE FROM call_events")
    suspend fun clearCallEvents()
}
