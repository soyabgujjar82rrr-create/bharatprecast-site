package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_preferences")
data class UserPreferencesEntity(
    @PrimaryKey val id: Int = 1,
    // Auth & Profile
    val isAuthenticated: Boolean = false,
    val userPhoneNumber: String = "",
    val userCountryCode: String = "+91",
    val userName: String = "",
    val userAvatar: String = "avatar_neural",
    val authUserId: String = "",

    // Setup Flow
    val isSetupCompleted: Boolean = false,
    val isConsentAgreed: Boolean = true,
    val currentSetupStep: String = "PHONE_LOGIN",

    // Assistant Settings
    val isAssistantEnabled: Boolean = true,
    val isCallAssistantEnabled: Boolean = true,
    val callScreeningMode: String = "ALERT", // ALERT, SPAM, GREETING
    val assistantLanguage: String = "en", // "en", "hi", "hinglish"
    val autoSpeakEnabled: Boolean = true,
    val speechRate: Float = 1.0f,
    val speechPitch: Float = 1.0f,

    // AI Call Assistant Specific
    val letAiAnswerCalls: Boolean = false,
    val askMeBeforeAiAnswers: Boolean = true,
    val transferCallToMeEnabled: Boolean = true,
    val callGreetingText: String = "Hello, this is EquiliAI Max. How may I help you?",
    val aiVoiceId: String = "aura",
    val saveTranscriptsConsent: Boolean = false,
    val generateAiSummaries: Boolean = true,
    val aiMemoryEnabled: Boolean = true,

    // Notification Categories
    val notifyCallHandled: Boolean = true,
    val notifySummaryReady: Boolean = true,
    val notifyImportantAiEvents: Boolean = true,
    val notifyPermissionReminders: Boolean = true,

    // Appearance (SYSTEM, LIGHT, DARK)
    val appearanceMode: String = "SYSTEM",

    // Privacy & Voice Audio Governance
    val retainVoiceData: Boolean = false,
    val biometricOrPinLockEnabled: Boolean = false
)
