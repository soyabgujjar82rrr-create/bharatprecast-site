package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "call_events")
data class CallEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val phoneNumber: String,
    val callerName: String,
    val state: String = "COMPLETED", // "RINGING", "ACTIVE", "COMPLETED", "SCREENED"
    val actionTaken: String = "AI Handled", // "AI Handled", "Transferred to Human", "Screened"
    val callDurationSeconds: Int = 0,
    val handlingStatus: String = "AI_ANSWERED", // "AI_ANSWERED", "TRANSFERRED_TO_HUMAN", "SCREENED", "MISSED"
    val reasonForCalling: String = "",
    val importantInformation: String = "",
    val actionRequested: String = "",
    val summary: String = "",
    val transcript: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
