package com.example.data.repository

import com.example.data.dao.CallEventDao
import com.example.data.dao.ChatMessageDao
import com.example.data.dao.UserPreferencesDao
import com.example.data.entity.CallEventEntity
import com.example.data.entity.ChatMessageEntity
import com.example.data.entity.UserPreferencesEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class EquiliRepository(
    private val preferencesDao: UserPreferencesDao,
    private val chatMessageDao: ChatMessageDao,
    private val callEventDao: CallEventDao
) {
    val preferencesFlow: Flow<UserPreferencesEntity> = preferencesDao.getPreferences().map {
        it ?: UserPreferencesEntity()
    }

    suspend fun getPreferencesDirect(): UserPreferencesEntity {
        return preferencesDao.getPreferencesDirect() ?: UserPreferencesEntity()
    }

    suspend fun updatePreferences(preferences: UserPreferencesEntity) {
        preferencesDao.savePreferences(preferences)
    }

    // Auth & Account
    suspend fun setUserAuthenticated(phoneNumber: String, countryCode: String, authUserId: String) {
        val current = getPreferencesDirect()
        preferencesDao.savePreferences(
            current.copy(
                isAuthenticated = true,
                userPhoneNumber = phoneNumber,
                userCountryCode = countryCode,
                authUserId = authUserId,
                currentSetupStep = "PROFILE_SETUP"
            )
        )
    }

    suspend fun setUserProfile(name: String, avatar: String) {
        val current = getPreferencesDirect()
        preferencesDao.savePreferences(
            current.copy(
                userName = name,
                userAvatar = avatar
            )
        )
    }

    suspend fun updateSetupStep(step: String) {
        val current = getPreferencesDirect()
        preferencesDao.savePreferences(current.copy(currentSetupStep = step))
    }

    suspend fun markSetupCompleted(isCompleted: Boolean) {
        val current = getPreferencesDirect()
        preferencesDao.savePreferences(
            current.copy(
                isSetupCompleted = isCompleted,
                currentSetupStep = if (isCompleted) "COMPLETED" else "PROFILE_SETUP"
            )
        )
    }

    suspend fun logout() {
        val current = getPreferencesDirect()
        preferencesDao.savePreferences(
            current.copy(
                isAuthenticated = false,
                isSetupCompleted = false,
                currentSetupStep = "PHONE_LOGIN"
            )
        )
    }

    suspend fun deleteAccount() {
        chatMessageDao.clearAllMessages()
        callEventDao.clearCallEvents()
        preferencesDao.savePreferences(UserPreferencesEntity())
    }

    suspend fun setConsentAgreed(agreed: Boolean) {
        val current = getPreferencesDirect()
        preferencesDao.savePreferences(current.copy(isConsentAgreed = agreed))
    }

    suspend fun setAssistantEnabled(enabled: Boolean) {
        val current = getPreferencesDirect()
        preferencesDao.savePreferences(current.copy(isAssistantEnabled = enabled))
    }

    suspend fun setCallAssistantEnabled(enabled: Boolean) {
        val current = getPreferencesDirect()
        preferencesDao.savePreferences(current.copy(isCallAssistantEnabled = enabled))
    }

    suspend fun setLetAiAnswerCalls(enabled: Boolean) {
        val current = getPreferencesDirect()
        preferencesDao.savePreferences(current.copy(letAiAnswerCalls = enabled))
    }

    suspend fun setAskMeBeforeAiAnswers(enabled: Boolean) {
        val current = getPreferencesDirect()
        preferencesDao.savePreferences(current.copy(askMeBeforeAiAnswers = enabled))
    }

    suspend fun setTransferCallToMeEnabled(enabled: Boolean) {
        val current = getPreferencesDirect()
        preferencesDao.savePreferences(current.copy(transferCallToMeEnabled = enabled))
    }

    suspend fun setCallGreetingText(greeting: String) {
        val current = getPreferencesDirect()
        preferencesDao.savePreferences(current.copy(callGreetingText = greeting))
    }

    suspend fun setAiVoiceId(voiceId: String) {
        val current = getPreferencesDirect()
        preferencesDao.savePreferences(current.copy(aiVoiceId = voiceId))
    }

    suspend fun setSaveTranscriptsConsent(consent: Boolean) {
        val current = getPreferencesDirect()
        preferencesDao.savePreferences(current.copy(saveTranscriptsConsent = consent))
    }

    suspend fun setGenerateAiSummaries(enabled: Boolean) {
        val current = getPreferencesDirect()
        preferencesDao.savePreferences(current.copy(generateAiSummaries = enabled))
    }

    suspend fun setCallScreeningMode(mode: String) {
        val current = getPreferencesDirect()
        preferencesDao.savePreferences(current.copy(callScreeningMode = mode))
    }

    suspend fun setAssistantLanguage(language: String) {
        val current = getPreferencesDirect()
        preferencesDao.savePreferences(current.copy(assistantLanguage = language))
    }

    suspend fun setAutoSpeak(enabled: Boolean) {
        val current = getPreferencesDirect()
        preferencesDao.savePreferences(current.copy(autoSpeakEnabled = enabled))
    }

    suspend fun setVoiceSettings(rate: Float, pitch: Float) {
        val current = getPreferencesDirect()
        preferencesDao.savePreferences(current.copy(speechRate = rate, speechPitch = pitch))
    }

    suspend fun setAiMemoryEnabled(enabled: Boolean) {
        val current = getPreferencesDirect()
        preferencesDao.savePreferences(current.copy(aiMemoryEnabled = enabled))
    }

    suspend fun setNotificationSettings(
        callHandled: Boolean,
        summaryReady: Boolean,
        aiEvents: Boolean,
        permissionReminders: Boolean
    ) {
        val current = getPreferencesDirect()
        preferencesDao.savePreferences(
            current.copy(
                notifyCallHandled = callHandled,
                notifySummaryReady = summaryReady,
                notifyImportantAiEvents = aiEvents,
                notifyPermissionReminders = permissionReminders
            )
        )
    }

    suspend fun setAppearanceMode(mode: String) {
        val current = getPreferencesDirect()
        preferencesDao.savePreferences(current.copy(appearanceMode = mode))
    }

    suspend fun setRetainVoiceData(retain: Boolean) {
        val current = getPreferencesDirect()
        preferencesDao.savePreferences(current.copy(retainVoiceData = retain))
    }

    // Chat messages
    val chatMessagesFlow: Flow<List<ChatMessageEntity>> = chatMessageDao.getAllMessages()

    suspend fun addChatMessage(
        sender: String,
        content: String,
        isError: Boolean = false,
        originalQuery: String = ""
    ): Long {
        return chatMessageDao.insertMessage(
            ChatMessageEntity(
                sender = sender,
                content = content,
                isError = isError,
                originalQuery = originalQuery
            )
        )
    }

    suspend fun clearChatMessages() {
        chatMessageDao.clearAllMessages()
    }

    // Call Events & History
    val callEventsFlow: Flow<List<CallEventEntity>> = callEventDao.getRecentCallEvents()

    suspend fun logCallEvent(
        phoneNumber: String,
        callerName: String,
        state: String,
        actionTaken: String,
        durationSeconds: Int = 0,
        handlingStatus: String = "AI_ANSWERED",
        reasonForCalling: String = "",
        importantInformation: String = "",
        actionRequested: String = "",
        transcript: String = "",
        summary: String = ""
    ): Long {
        val prefs = getPreferencesDirect()
        val safeTranscript = if (prefs.saveTranscriptsConsent) transcript else ""
        return callEventDao.insertCallEvent(
            CallEventEntity(
                phoneNumber = phoneNumber,
                callerName = callerName,
                state = state,
                actionTaken = actionTaken,
                callDurationSeconds = durationSeconds,
                handlingStatus = handlingStatus,
                reasonForCalling = reasonForCalling,
                importantInformation = importantInformation,
                actionRequested = actionRequested,
                transcript = safeTranscript,
                summary = summary
            )
        )
    }

    suspend fun deleteCallEvent(id: Long) {
        callEventDao.deleteCallEventById(id)
    }

    suspend fun clearCallSummary(id: Long) {
        callEventDao.clearCallSummary(id)
    }

    suspend fun clearCallTranscript(id: Long) {
        callEventDao.clearCallTranscript(id)
    }

    suspend fun clearAllCallSummaries() {
        callEventDao.clearAllCallSummaries()
    }

    suspend fun clearAllCallTranscripts() {
        callEventDao.clearAllCallTranscripts()
    }

    suspend fun clearCallEvents() {
        callEventDao.clearCallEvents()
    }
}
