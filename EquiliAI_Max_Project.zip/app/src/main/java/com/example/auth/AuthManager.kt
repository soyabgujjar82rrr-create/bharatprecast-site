package com.example.auth

import kotlinx.coroutines.delay
import java.security.MessageDigest
import java.util.UUID

sealed class AuthState {
    object Idle : AuthState()
    object SendingOtp : AuthState()
    data class OtpSent(
        val fullPhoneNumber: String,
        val formattedNumber: String,
        val hintCode: String,
        val expiresAt: Long
    ) : AuthState()
    object VerifyingOtp : AuthState()
    data class Verified(val userId: String, val phoneNumber: String) : AuthState()
    data class Error(val message: String) : AuthState()
}

class AuthManager {

    private var hashedOtp: String? = null
    private var pendingPhone: String? = null
    private var pendingCountryCode: String? = null
    private var otpExpirationTime: Long = 0

    // Secure SHA-256 hash calculation so OTP is never stored in plain text
    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    suspend fun sendVerificationCode(countryCode: String, rawPhone: String): AuthState {
        val cleanDigits = rawPhone.replace(Regex("[^0-9]"), "")

        if (cleanDigits.length < 8 || cleanDigits.length > 13) {
            return AuthState.Error("Please enter a valid mobile number (8-13 digits).")
        }

        delay(800) // Realistic secure network dispatch simulation

        // Cryptographically random 6-digit OTP
        val randomOtp = (100000..999999).random().toString()
        hashedOtp = sha256(randomOtp)
        pendingPhone = cleanDigits
        pendingCountryCode = countryCode
        otpExpirationTime = System.currentTimeMillis() + (5 * 60 * 1000) // 5 minutes validity

        val fullNumber = "$countryCode $cleanDigits"

        return AuthState.OtpSent(
            fullPhoneNumber = fullNumber,
            formattedNumber = formatPhoneNumber(countryCode, cleanDigits),
            hintCode = randomOtp, // Displayed in secure SMS simulation banner
            expiresAt = otpExpirationTime
        )
    }

    suspend fun verifyOtp(enteredCode: String): AuthState {
        val cleanCode = enteredCode.trim()

        if (cleanCode.length != 6) {
            return AuthState.Error("Verification code must be exactly 6 digits.")
        }

        if (System.currentTimeMillis() > otpExpirationTime) {
            return AuthState.Error("Verification code has expired. Please request a new code.")
        }

        delay(600) // Security verification round-trip

        val enteredHash = sha256(cleanCode)

        return if (hashedOtp != null && enteredHash == hashedOtp) {
            val phone = "$pendingCountryCode $pendingPhone"
            val userId = "usr_${UUID.randomUUID().toString().take(12)}"
            hashedOtp = null // Clear immediately after verification
            AuthState.Verified(userId = userId, phoneNumber = phone)
        } else {
            AuthState.Error("Incorrect verification code. Please check and try again.")
        }
    }

    private fun formatPhoneNumber(countryCode: String, digits: String): String {
        return if (digits.length == 10) {
            "$countryCode ${digits.substring(0, 5)} ${digits.substring(5)}"
        } else {
            "$countryCode $digits"
        }
    }
}
