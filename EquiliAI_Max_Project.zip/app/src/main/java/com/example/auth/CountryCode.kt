package com.example.auth

data class CountryCode(
    val code: String,
    val countryName: String,
    val flagEmoji: String,
    val minLength: Int = 10,
    val maxLength: Int = 10
)

object CountryCodes {
    val ALL = listOf(
        CountryCode(code = "+91", countryName = "India", flagEmoji = "🇮🇳", minLength = 10, maxLength = 10),
        CountryCode(code = "+1", countryName = "United States", flagEmoji = "🇺🇸", minLength = 10, maxLength = 10),
        CountryCode(code = "+44", countryName = "United Kingdom", flagEmoji = "🇬🇧", minLength = 10, maxLength = 11),
        CountryCode(code = "+971", countryName = "United Arab Emirates", flagEmoji = "🇦🇪", minLength = 9, maxLength = 9),
        CountryCode(code = "+61", countryName = "Australia", flagEmoji = "🇦🇺", minLength = 9, maxLength = 9),
        CountryCode(code = "+49", countryName = "Germany", flagEmoji = "🇩🇪", minLength = 10, maxLength = 11),
        CountryCode(code = "+33", countryName = "France", flagEmoji = "🇫🇷", minLength = 9, maxLength = 9),
        CountryCode(code = "+81", countryName = "Japan", flagEmoji = "🇯🇵", minLength = 10, maxLength = 10),
        CountryCode(code = "+65", countryName = "Singapore", flagEmoji = "🇸🇬", minLength = 8, maxLength = 8),
        CountryCode(code = "+966", countryName = "Saudi Arabia", flagEmoji = "🇸🇦", minLength = 9, maxLength = 9)
    )

    fun getDefault(): CountryCode = ALL.first()
}
