package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.ai.EquiliAIEngine
import com.example.callassistant.AiVoiceProfiles
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read app name from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("EquiliAI Max", appName)
  }

  @Test
  fun `test ai engine local response generation`() {
    val engine = EquiliAIEngine()
    val response = engine.generateLocalResponse("hello", "en", false)
    assertNotNull(response)
    assertTrue(response.contains("EquiliAI Max"))
  }

  @Test
  fun `test ai engine call context response`() {
    val engine = EquiliAIEngine()
    val response = engine.generateCallLocalResponse("transfer", "en")
    assertNotNull(response)
    assertTrue(response.contains("transfer", ignoreCase = true))
  }

  @Test
  fun `test ai voice profiles exist`() {
    val profiles = AiVoiceProfiles.ALL
    assertTrue(profiles.isNotEmpty())
    val aura = AiVoiceProfiles.getById("aura")
    assertEquals("aura", aura.id)
  }

  @Test
  fun `test call summary generation`() = runBlocking {
    val engine = EquiliAIEngine()
    val summary = engine.generateCallSummary("CALLER: Please call me back tomorrow.", "en")
    assertNotNull(summary)
    assertTrue(summary.isNotBlank())
  }
}
