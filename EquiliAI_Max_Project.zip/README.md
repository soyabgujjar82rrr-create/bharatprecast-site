# EquiliAI Max — Next-Generation AI Voice, Call Screening & Chat Intelligence

EquiliAI Max is a production-ready, full-stack Android application built with Kotlin and Jetpack Compose. It combines autonomous AI call screening, natural conversational chat, speech recognition, voice synthesis, multi-turn AI memory, and comprehensive application governance into a modular Android architecture.

---

## Key Modules & Features

### 1. Authentication & Security
- **Phone Number & OTP Login**: Secure authentication flow with automated SMS simulation and cryptographic SHA-256 validation tokens.
- **Session Management**: Isolated, authenticated sessions with instant logout and complete account deletion safeguards.
- **Zero Plain-Text Credentials**: API keys, passwords, and OTP secrets are never stored in plain text.
- **Android App Sandbox**: All application state and transcripts reside strictly inside the protected SQLite Room sandbox.

### 2. AI Chat & Voice Assistant
- **Interactive Multi-Turn Chat**: Natural language dialogue powered by Google Gemini 2.5 Flash with local neural fallback.
- **Typing Indicators & Error Recovery**: Animated loading indicators and one-tap prompt retry controls for network or API interruptions.
- **Real-Time Speech Recognition & TTS**: Seamless speech-to-text via Android `SpeechRecognizer` and natural voice synthesis with custom pitch and tempo controls.
- **Instant Mute**: Quick-action audio silencing button while the assistant is speaking.
- **AI Memory Governance**: Session memory buffer controls allowing users to maintain context, clear memory, or start fresh conversation threads.

### 3. AI Call Screening & Telephony Assistant
- **Incoming Call Detection**: Real-time screening alerts compliant with official Android Telecom APIs.
- **Autonomous & Guided Screening**: Options to let AI answer unknown callers, filter spam, or greet callers with customized text.
- **Live Call Screen Overlay**: Heads-up screening visualizer with live caller transcript streaming and one-tap call transfer.
- **Call Summaries & Action Items**: Structured extraction of caller intent, urgency, and requested follow-ups.

### 4. Settings & Management Hub
- **Account Management**: Profile avatar selector, display name customization, and verified phone details.
- **Voice & Language Settings**: 4 AI voice personalities (Aura, Zephyr, Nova, Kavya) with audio preview; full support for English, हिन्दी (Hindi), and Hinglish.
- **Notification Categories**: Independent toggles for Call Handled, Call Summary Ready, Important AI Events, and Permission Reminders across dedicated notification channels.
- **Appearance & Theming**: Instant switching between System Default, Light Mode, and Dark Mode with electric indigo and cyan accents.
- **Permission Center**: Granular status auditing for Microphone, Phone State, Contacts, and Notifications.
- **Privacy & Data Governance**: Zero-secret recording commitment, clear chat history, delete stored transcripts, and delete account.
- **Help & Support**: Built-in FAQ, troubleshooting guides, permission explainers, and support ticket submissions.
- **About & Legal Disclosures**: Privacy Policy, Terms of Service, and open-source license attributions.

---

## Project Structure

```
├── app/
│   ├── build.gradle.kts                # Module build configurations & dependencies
│   ├── google-services.json            # Google/Firebase service configuration placeholder
│   ├── proguard-rules.pro              # Proguard optimization & obfuscation rules
│   └── src/main/
│       ├── AndroidManifest.xml         # Permissions, receivers & activity definitions
│       ├── java/com/example/
│       │   ├── EquiliApplication.kt    # Application singleton & dependency container
│       │   ├── MainActivity.kt         # Edge-to-edge Compose activity & screen router
│       │   ├── ai/                     # Gemini REST client & on-device neural engine
│       │   ├── auth/                   # Phone OTP authentication manager
│       │   ├── callassistant/          # Call screening, telephony receiver & models
│       │   ├── data/                   # Room database, DAOs, entities & repository
│       │   ├── notifications/          # Android 8.0+ notification channels & dispatcher
│       │   ├── permissions/            # Granular runtime permission helpers & models
│       │   ├── ui/                     # Compose theme, components & all feature screens
│       │   └── voice/                  # SpeechRecognizer & TextToSpeech managers
│       └── res/                        # Vector drawables, themes, colors & strings
├── gradle/
│   └── libs.versions.toml              # Centralized version catalog
├── build.gradle.kts                    # Root build configuration
├── settings.gradle.kts                 # Project modules & repository definitions
├── .env.example                        # Template for environment secrets
└── README.md                           # Documentation & build guide
```

---

## How to Export & Download as a ZIP

In Google AI Studio:
1. Click the **Project Menu** (or settings/export icon) at the top of the AI Studio window.
2. Select **Export as ZIP** to download the complete archive containing all source files, Gradle scripts, resources, and configurations.
3. Alternatively, click **Push to GitHub** to sync this repository directly to your personal GitHub account, where you can click **Code → Download ZIP**.

---

## Local Setup & Building in Android Studio

1. **Extract Archive**:
   Extract the downloaded ZIP file to your local computer.

2. **Open in Android Studio**:
   Launch Android Studio (Ladybug or newer recommended) and select **Open**, choosing the project's root folder.

3. **API Key Setup**:
   Copy `.env.example` to `.env` in the root folder and add your Gemini API key:
   ```env
   GEMINI_API_KEY=your_actual_gemini_api_key_here
   ```
   *(Note: The app will continue to run with the built-in on-device neural engine even without an API key).*

4. **Build APK**:
   Run the Gradle build command:
   ```bash
   ./gradlew assembleDebug
   ```
   The compiled APK will be generated at `app/build/outputs/apk/debug/app-debug.apk`.

5. **Run on Device or Emulator**:
   Connect an Android device with Developer Mode / USB Debugging enabled, or start an Android Virtual Device (AVD), and click **Run 'app'** in Android Studio.
